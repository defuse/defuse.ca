<?php

require_once('inc/db.inc.php');
require_once('inc/security.inc.php');

if(isset($_POST['submit']))
{
	if(empty($_POST['username']))
	{
		FailError("ERROR_NO_USERNAME");
		die();
	}

	if(ContainsNonAlpha($_POST['username']))
	{
		FailError("ERROR_NONALPHA_USERNAME");
		die();
	}

	if(UsernameExists($_POST['username']))
	{
		FailError("ERROR_EXISTING_USER");
		die();
	}

	if(empty($_POST['pass1']))
	{
		FailError("ERROR_NO_PASSWORD");
		die();
	}

	if($_POST['pass1'] != $_POST['pass2'])
	{
		FailError("ERROR_PASS_NOT_MATCH");
		die();
	}

	//Everything is valid..
	$safe_hash = mysql_real_escape_string(Security::HashPassword($_POST['pass1']));
	$safe_user = mysql_real_escape_string($_POST['username']);

	$res = mysql_query("INSERT INTO users (username, password) VALUES('$safe_user', '$safe_hash')");

	if(!$res)
	{
		FailError("ERROR_CREATING_ACCOUNT");
		die();
	}

	header('Location: index.php?c=true');
	
}

function FailError($type)
{
	header('Location: index.php?e=' . $type);
}

function ContainsNonAlpha($check)
{
	for($i = 0; $i < strlen($check); $i++)
	{
		$c = $check[$i];
		if( !($c >= 'A' && $c <= 'Z' || $c >= 'a' && $c <= 'z') ) //if not alpha
			return true;
	}
	return false;
}

function UsernameExists($check)
{
	$check = mysql_real_escape_string($check);
	$q = mysql_query("SELECT * FROM users WHERE username='$check'");
	if(!$q) return false;
	return mysql_num_rows($q) !== 0;
}

?>

