Defuse Cyber-Security's Race Condition Vulnerability Proof of Concept
    https://defuse.ca/race-conditions-in-web-applications.htm

To run the proof of concept yourself, just setup a MySQL database using the 
provided server/payhack.sql file, set the password in server/poc.php and then 
move server/poc.php into any folder where it will be executed by the web 
server. To run the test, set the correct URL in client/get.py and execute:
    
    $ python client/get.py | tee testResults

If you have any comments/questions you can find my contact info here:
    https://defuse.ca/contact.htm
