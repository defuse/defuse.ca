﻿/*
 *  DataLeak - A filesystem event monitoring tool
 *  Copyright (C) 2011 FireXware (http://ossbox.com)
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 * WWW: http://ossbox.com/
 * Contact: firexware@gmail.com
 * GPG: 0xD46B8253685EE48F @ pgp.mit.edu
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace DataLeak
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            fsWatcher.EnableRaisingEvents = false;
            fsWatcher.IncludeSubdirectories = true;
            try
            {
                fsWatcher.Path = "C:\\";
            }
            catch
            {
                //Just in case they don't have a C: drive :P
            }
            fsWatcher.Changed += new System.IO.FileSystemEventHandler(fsAnyEvent);
            fsWatcher.Created += new System.IO.FileSystemEventHandler(fsAnyEvent);
            fsWatcher.Deleted += new System.IO.FileSystemEventHandler(fsAnyEvent);
            fsWatcher.Renamed += new System.IO.RenamedEventHandler(fsAnyEvent);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        void fsAnyEvent(object sender, System.IO.FileSystemEventArgs e)
        {
            //in the case of a rename, we can get the old filename too
            if (e.ChangeType == WatcherChangeTypes.Renamed)
            {
                RenamedEventArgs e2 = (RenamedEventArgs)e;
                lstFiles.Items.Add(e2.ChangeType.ToString() + " (old): " + e2.OldFullPath);
                lstFiles.Items.Add(e2.ChangeType.ToString() + " (new): " + e2.FullPath);
            }
            else
            {
                lstFiles.Items.Add(e.ChangeType.ToString() + ": " + e.FullPath);
            }
        }

        private void mnuStart_Click(object sender, EventArgs e)
        {
            fsWatcher.EnableRaisingEvents = true;
            mnuStop.Enabled = true;
            mnuStart.Enabled = false;
        }

        private void mnuStop_Click(object sender, EventArgs e)
        {
            fsWatcher.EnableRaisingEvents = false;
            mnuStop.Enabled = false;
            mnuStart.Enabled = true;
        }

        private void mnuRoot_Click(object sender, EventArgs e)
        {
            try
            {
                FolderBrowserDialog dlg = new FolderBrowserDialog();
                DialogResult res = dlg.ShowDialog();
                if (res == DialogResult.OK)
                {
                    fsWatcher.Path = dlg.SelectedPath;
                }
            }
            catch
            {
                MessageBox.Show("There was an error listening for filesystem events for that folder. If you are trying to listen to events inside a folder you don't have access to, select the PARENT folder.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                mnuRoot_Click(sender, e);
            }
            MessageBox.Show("Listening for events in " + fsWatcher.Path);
        }

        private void mnuExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "Text Files (*.txt)|*.txt";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                FileStream fs = new FileStream(dlg.FileName, FileMode.Create, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                foreach (string path in lstFiles.Items)
                {
                    sw.WriteLine(path);
                }
                sw.Close();
                fs.Close();
                MessageBox.Show("File list saved.");
            }
        }
    }
}
