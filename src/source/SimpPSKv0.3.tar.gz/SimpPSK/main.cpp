//SimpPSK Demo - see SimpPSK.h for documentation
//Created by FireXware
//Contact: firexware@gmail.com
//Website: OSSBox.com

#include <iostream>
#include "include/SimpPSK.h"

using namespace std;

void PrintHex(unsigned int num)
{
    if(num < 10)
        cout << num;
    else
    {
        cout << (char)('A' + num - 10);
    }
}

void DumpBytes(unsigned char* bytes, unsigned int len)
{
    cout << "Length: " << len << "\n";
    for(unsigned int i = 0; i < len; i+= 32)
    {
        for(unsigned int j = 0; j < 32 && j+i < len; j++)
        {
            PrintHex(bytes[i+j] >> 4);
            PrintHex(bytes[i+j] % 16);
        }
        cout << "\n";
    }
    cout << "\n\n";
}

int main()
{
    //ATTACK DETECTION TESTING:
    //0 - no attack
    //1 - client salt change
    //2 - client challenge change
    //3 - server salt change
    //4 - server response change
    //5 - server challenge change
    //6 - client response change
    //7 - wrong password
    //8 - attacker lowers security version
    int attack = 0;

    unsigned char cPassword[7] = "ABCDEF";
    unsigned char sPassword[7] =  "ABCDEF";

    cout << "Client Password: \n";
    DumpBytes(cPassword,6);

    cout << "Server Password: \n";
    DumpBytes(cPassword,6);

    if(attack == 7)
    {
        cPassword[0] += 1;
    }

    SimpPSK server(sPassword, 6, VER_SHA256);
    SimpPSK client(cPassword, 6, VER_SHA256);

    try{
        int len = 0;

        len = client.GetAuthRequestSize();
        unsigned char authRequest[len];
        client.StartAuthRequest(authRequest);

        cout << "AuthRequest: \n";
        DumpBytes(authRequest, len);

        if(attack == 1)
        {
            authRequest[0] += 1;
        }

        if(attack == 2)
        {
            authRequest[40] += 1;
        }

        if(attack == 8)
        {
            authRequest[len - 1] = VER_SHA256 - 1;
        }
        server.AcceptAuthRequest(authRequest);
        len = server.GetAuthReplySize();
        unsigned char authReply[len];
        server.GetAuthReply(authReply);

        cout << "AuthReply: \n";
        DumpBytes(authReply, len);

        if(attack == 3)
        {
            authReply[0] += 1;
        }

        if(attack == 4)
        {
            authReply[40] += 1;
        }

        if(attack == 5)
        {
            authReply[70] += 1;
        }

        client.AcceptAuthReply(authReply);
        len = client.GetAuthFinalizeSize();
        unsigned char authFinalize[len];
        client.GetAuthFinalize(authFinalize);

        cout << "AuthFinalize: \n";
        DumpBytes(authFinalize, len);

        if(attack == 6)
        {
            authFinalize[0] += 1;
        }

        server.AcceptAuthFinalize(authFinalize);

        if(server.ValidAuthentication())
        {
            cout << "SERVER SAYS: VALID!\n";
            cout << "SESSION KEY: \n";
            unsigned char key[SimpPSK::SESSION_KEY_LENGTH];
            server.GetSessionKey(key);
            DumpBytes(key, SimpPSK::SESSION_KEY_LENGTH);
        }
        else
        {
            cout << "SERVER SAYS: FAYUL!\n";
        }

        if(client.ValidAuthentication())
        {
            cout << "CLIENT SAYS: VALID!\n";
            cout << "SESSION KEY: \n";
            unsigned char key[SimpPSK::SESSION_KEY_LENGTH];
            client.GetSessionKey(key);
            DumpBytes(key, SimpPSK::SESSION_KEY_LENGTH);
        }
        else
        {
            cout << "CLIENT SAYS: FAYUL!\n";
        }
    }
    catch (int err)
    {
        cout << "ERROR #" << err << ": " << SimpPSK::GetErrorMessage(err);
    }

    return 0;
}
