//SimpPSK - see SimpPSK.h for documentation
//Created by FireXware
//Contact: firexware@gmail.com
//Website: OSSBox.com

#include "../include/SimpPSK.h"

#include "openssl/sha.h"


#include <string.h>

//headers needed for the CSPRNG
#ifdef _WIN32
    #include <Windows.h>
    #include <Wincrypt.h>
#else
    #include <fstream> //for reading from /dev/urandom on *nix systems
#endif

////for debugging
//#include <iostream>
//using namespace std;


//NOTE: I used explicit lengths for the unsigned char arrays in the function defintions, not sure if that is good practice or not :/

const unsigned int SimpPSK::SESSION_KEY_LENGTH = SECURE_HASH_BYTE_LENGTH ; //MUST be the same as SECURE_HASH_BYTE_LENGTH



SimpPSK::SimpPSK(unsigned char* password, unsigned int passwordLength)
{
    _sharedKey = new unsigned char[SECURE_HASH_BYTE_LENGTH];
    _sessionKey = new unsigned char[SESSION_KEY_LENGTH];
    _serverRandomSalt = new unsigned char[RANDOM_SEED_BYTE_LENGTH];
    _clientRandomSalt = new unsigned char[RANDOM_SEED_BYTE_LENGTH];
    _clientChallenge = new unsigned char[RANDOM_SEED_BYTE_LENGTH];
    _clientResponse = new unsigned char[SECURE_HASH_BYTE_LENGTH];
    _serverChallenge = new unsigned char[RANDOM_SEED_BYTE_LENGTH];
    _serverResponse = new unsigned char[SECURE_HASH_BYTE_LENGTH];

    this->_state = STATE_NONE;
    this->SecureHash(password, passwordLength, this->_sharedKey); //hash the password into the shared key
}

SimpPSK::~SimpPSK()
{
    delete[] _sharedKey;
    delete[] _sessionKey;
    delete[] _serverRandomSalt;
    delete[] _clientRandomSalt;
    delete[] _clientChallenge;
    delete[] _clientResponse;
    delete[] _serverChallenge;
    delete[] _serverResponse;
}

unsigned int SimpPSK::GetAuthRequestSize()
{
    return 2 * RANDOM_SEED_BYTE_LENGTH;
}

void SimpPSK::StartAuthRequest(unsigned char buf[2 * RANDOM_SEED_BYTE_LENGTH])
{
    //<client salt> . <client challenge>
    if(this->_state == STATE_NONE)
    {
        this->_state = STATE_CLIENT_SENT_AUTH;

        this->FillRandom(_clientChallenge, RANDOM_SEED_BYTE_LENGTH);
        this->FillRandom(_clientRandomSalt, RANDOM_SEED_BYTE_LENGTH);

        memcpy(buf, _clientRandomSalt, RANDOM_SEED_BYTE_LENGTH);
        memcpy(buf + RANDOM_SEED_BYTE_LENGTH, _clientChallenge, RANDOM_SEED_BYTE_LENGTH);
    }
    else
    {
        throw BADSTATE_START_AUTH_REQUEST;
    }
}

void SimpPSK::AcceptAuthRequest(unsigned char authRequest[2 * RANDOM_SEED_BYTE_LENGTH])
{
    //<client salt> . <client challenge>
    if(this->_state == STATE_NONE)
    {
        this->_state = STATE_SERVER_GOT_AUTH;

        FillRandom(_serverRandomSalt, RANDOM_SEED_BYTE_LENGTH);

        memcpy(this->_clientRandomSalt, authRequest, RANDOM_SEED_BYTE_LENGTH);
        memcpy(this->_clientChallenge, authRequest + RANDOM_SEED_BYTE_LENGTH, RANDOM_SEED_BYTE_LENGTH);

        _sessionKey = new unsigned char[SECURE_HASH_BYTE_LENGTH];
        this->CreateSessionKey(this->_sharedKey, this->_clientRandomSalt, this->_serverRandomSalt, this->_sessionKey);

    }
    else
    {
        throw BADSTATE_ACCEPT_AUTH_REQUEST;
    }
}

unsigned int SimpPSK::GetAuthReplySize()
{
    return RANDOM_SEED_BYTE_LENGTH + SECURE_HASH_BYTE_LENGTH + RANDOM_SEED_BYTE_LENGTH;
}

void SimpPSK::GetAuthReply(unsigned char buf[RANDOM_SEED_BYTE_LENGTH + SECURE_HASH_BYTE_LENGTH + RANDOM_SEED_BYTE_LENGTH])//server
{
    //<server salt> . <server (challenge) response> . <server challenge>
    if(this->_state == STATE_SERVER_GOT_AUTH)
    {
        this->_state = STATE_SERVER_SENT_AUTH_REPLY;
        //randomsalt,challengeresponse
        unsigned char responseBuffer[SECURE_HASH_BYTE_LENGTH + RANDOM_SEED_BYTE_LENGTH]; //sessionkey . challenge
        memcpy(responseBuffer, this->_sessionKey, SECURE_HASH_BYTE_LENGTH);
        memcpy(responseBuffer + SECURE_HASH_BYTE_LENGTH, this->_clientChallenge, RANDOM_SEED_BYTE_LENGTH);

        unsigned char challengeResponse[SECURE_HASH_BYTE_LENGTH];
        SecureHash(responseBuffer, SECURE_HASH_BYTE_LENGTH + RANDOM_SEED_BYTE_LENGTH, challengeResponse);

        this->_serverChallenge = new unsigned char[RANDOM_SEED_BYTE_LENGTH];
        FillRandom(_serverChallenge, RANDOM_SEED_BYTE_LENGTH);

        //this->_serverRandomSalt,challengeResponse,serverChallenge

        memcpy(buf, _serverRandomSalt, RANDOM_SEED_BYTE_LENGTH);
        memcpy(buf + RANDOM_SEED_BYTE_LENGTH, challengeResponse, SECURE_HASH_BYTE_LENGTH);
        memcpy(buf + RANDOM_SEED_BYTE_LENGTH + SECURE_HASH_BYTE_LENGTH, _serverChallenge, RANDOM_SEED_BYTE_LENGTH);
    }
    else
    {
        throw BADSTATE_GET_AUTH_REPLY;
    }
}

void SimpPSK::AcceptAuthReply(unsigned char authReply[RANDOM_SEED_BYTE_LENGTH + SECURE_HASH_BYTE_LENGTH + RANDOM_SEED_BYTE_LENGTH]) //client
{
    //<server salt> . <server (challenge) response> . <server challenge>
    if(this->_state == STATE_CLIENT_SENT_AUTH)
    {
        this->_state = STATE_CLIENT_GOT_AUTH_REPLY;

        memcpy(_serverRandomSalt, authReply, RANDOM_SEED_BYTE_LENGTH);
        memcpy(_serverResponse, authReply + RANDOM_SEED_BYTE_LENGTH, SECURE_HASH_BYTE_LENGTH);
        memcpy(_serverChallenge, authReply + RANDOM_SEED_BYTE_LENGTH + SECURE_HASH_BYTE_LENGTH, RANDOM_SEED_BYTE_LENGTH);

        _sessionKey = new unsigned char[SECURE_HASH_BYTE_LENGTH];
        this->CreateSessionKey(this->_sharedKey, this->_clientRandomSalt, this->_serverRandomSalt, this->_sessionKey);
    }
    else
    {
        throw BADSTATE_ACCEPT_AUTH_REPLY;
    }
}

unsigned int SimpPSK::GetAuthFinalizeSize()
{
    return SECURE_HASH_BYTE_LENGTH;
}

void SimpPSK::GetAuthFinalize(unsigned char buf[SECURE_HASH_BYTE_LENGTH]) //client
{
    //<client (challenge) response>
    if(this->_state == STATE_CLIENT_GOT_AUTH_REPLY)
    {
        this->_state = STATE_CLIENT_SENT_AUTH_FINALIZE;
        //reply with challenge response
        unsigned char responseBuffer[SECURE_HASH_BYTE_LENGTH + RANDOM_SEED_BYTE_LENGTH]; //sessionkey . challenge
        memcpy(responseBuffer, this->_sessionKey, SECURE_HASH_BYTE_LENGTH);
        memcpy(responseBuffer + SECURE_HASH_BYTE_LENGTH, this->_serverChallenge, RANDOM_SEED_BYTE_LENGTH);

        SecureHash(responseBuffer, SECURE_HASH_BYTE_LENGTH + RANDOM_SEED_BYTE_LENGTH, buf);
    }
    else
    {
        throw BADSTATE_GET_AUTH_FINALIZE;
    }
}

void SimpPSK::AcceptAuthFinalize(unsigned char authFinalize[SECURE_HASH_BYTE_LENGTH]) //server
{
    //<client (challenge) response>
    if(this->_state == STATE_SERVER_SENT_AUTH_REPLY)
    {
        this->_state = STATE_SERVER_RECEIVED_AUTH_FINALIZE;

        memcpy(_clientResponse, authFinalize, SECURE_HASH_BYTE_LENGTH);
    }
    else
    {
       throw BADSTATE_ACCEPT_AUTH_FINALIZE;
    }
}

bool SimpPSK::ValidAuthentication()
{
    if(_state == STATE_CLIENT_SENT_AUTH_FINALIZE)
    {
        unsigned char hash[SECURE_HASH_BYTE_LENGTH];
        ComputeChallengeResponse(_clientChallenge, hash);
        if(memcmp(hash, _serverResponse, SECURE_HASH_BYTE_LENGTH) == 0)
        {
            _state = STATE_AUTHENTICATED;
            return true;
        }
    }
    else if(_state == STATE_SERVER_RECEIVED_AUTH_FINALIZE)
    {
        unsigned char hash[SECURE_HASH_BYTE_LENGTH];
        ComputeChallengeResponse(_serverChallenge, hash);
        if(memcmp(hash, _clientResponse, SECURE_HASH_BYTE_LENGTH) == 0)
        {
            _state = STATE_AUTHENTICATED;
            return true;
        }
    }
    else
    {
        throw BADSTATE_VALID_AUTHENTICATION;
    }
    return false; //die warning!
}

void SimpPSK::GetSessionKey(unsigned char keyBuf[SESSION_KEY_LENGTH])
{
    if(_state == STATE_AUTHENTICATED)
    {
         memcpy(keyBuf, _sessionKey, SESSION_KEY_LENGTH);
    }
    else
    {
        throw BADSTATE_GET_SESSION_KEY;
    }
}
//private
void SimpPSK::CreateSessionKey(unsigned char sharedKey[SECURE_HASH_BYTE_LENGTH], unsigned char clientSalt[RANDOM_SEED_BYTE_LENGTH], unsigned char* serverSalt, unsigned char keyBuf[SECURE_HASH_BYTE_LENGTH])
{
    unsigned char allData[SECURE_HASH_BYTE_LENGTH + 2 * RANDOM_SEED_BYTE_LENGTH];

    memcpy(allData, sharedKey, SECURE_HASH_BYTE_LENGTH);
    memcpy(allData + SECURE_HASH_BYTE_LENGTH, clientSalt, RANDOM_SEED_BYTE_LENGTH);
    memcpy(allData + SECURE_HASH_BYTE_LENGTH + RANDOM_SEED_BYTE_LENGTH, serverSalt, RANDOM_SEED_BYTE_LENGTH);

    SecureHash(allData, SECURE_HASH_BYTE_LENGTH + 2 * RANDOM_SEED_BYTE_LENGTH, keyBuf);
}
void SimpPSK::SecureHash(unsigned char* data, unsigned int dataLength, unsigned char buf[SECURE_HASH_BYTE_LENGTH])
{
    //using SHA256 from OpenSSL: (feel free to replace this function with another secure hash of your choice)

    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, data, dataLength);
    SHA256_Final(buf, &sha256);

    //For testing - THIS IS NOT AT ALL A SECURE HASH, TESTING PURPOSES ONLY
    /*for(unsigned int i = 0; i < SECURE_HASH_BYTE_LENGTH; i++)
        buf[i] = 0;
    #error YOU ARE USING THE INSECURE TESTING "hash". YOU MUST SUBSTITUTE THIS FOR A REAL HASH FUNCTION
    for(unsigned int i = 0; i < dataLength; i++)
    {
        buf[i % SECURE_HASH_BYTE_LENGTH] += data[i];
    }*/
}

void SimpPSK::ComputeChallengeResponse(unsigned char challenge[RANDOM_SEED_BYTE_LENGTH], unsigned char responseBuf[SECURE_HASH_BYTE_LENGTH])
{
    unsigned char responseBuffer[SECURE_HASH_BYTE_LENGTH + RANDOM_SEED_BYTE_LENGTH]; //sessionkey . challenge

    memcpy(responseBuffer, this->_sessionKey, SECURE_HASH_BYTE_LENGTH);
    memcpy(responseBuffer + SECURE_HASH_BYTE_LENGTH, challenge, RANDOM_SEED_BYTE_LENGTH);

    SecureHash(responseBuffer, SECURE_HASH_BYTE_LENGTH + RANDOM_SEED_BYTE_LENGTH, responseBuf);
}

void SimpPSK::FillRandom(unsigned char* buf, unsigned int bufLength)
{
    #ifdef _WIN32 //TODO: not tested
        //WIN32 CSPRNG thanks to: http://www.tomhandal.com/DevBlog/2010/03/17/cryptographically-random-bytes-in-microsoft-windows/
        HCRYPTPROV hCryptCtx = NULL;
        CryptAcquireContext(&hCryptCtx, NULL, MS_DEF_PROV, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT);
        CryptGenRandom(hCryptCtx, bufLength, buf);
        CryptReleaseContext(hCryptCtx, 0);
    #else
        std::ifstream devRand ("/dev/urandom", std::ios::in | std::ios::binary);
        bool suc = devRand.read((char*)buf,bufLength);
        devRand.close();
        if(!suc)
            throw RNG_FAIL;
        //TODO: throw error
    #endif
}
