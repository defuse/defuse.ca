	
		<div class="box">
		<div class="headerbar"><h3>Trust</h3></div>
			<div class="insidebox">
			<center>
				<a href="security.php" >Security Tips</a>
				&nbsp;&nbsp;&nbsp;
				<a href="docs/index.html" target="_blank" >
					User Guide and Technical Details
				</a>
			</center>
			</div>
		</div>
		
				
	</div>
</div>
	

</body>

</html>
