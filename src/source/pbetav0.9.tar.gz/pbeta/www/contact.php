<?php //This page provides contact information 
    //This file is part of Password Bolt.

    //Password Bolt is free software: you can redistribute it and/or modify
    //it under the terms of the GNU General Public License as published by
    //the Free Software Foundation, either version 3 of the License, or
    //(at your option) any later version.

    //Password Bolt is distributed in the hope that it will be useful,
    //but WITHOUT ANY WARRANTY; without even the implied warranty of
    //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    //GNU General Public License for more details.

    //You should have received a copy of the GNU General Public License
    //along with Password Bolt.  If not, see <http://www.gnu.org/licenses/>.
	//include ('libs/loginsys.php');
	include ('shortcuts/top.php');
?>
<!--Contact info box-->
<div class="box">
<div class="headerbar"><h3>Contact Information</h3></div>
	<div class="insidebox">
		<center>
			<h4>Email</h4>
			<br />
			<h4>Programmer</h4><img src="images/email.jpg" alt="Email Address" />
			<br />
			<br />
			Please contact us if you have any feedback, questions, or concerns.
		</center>
	</div>
</div>
<?php
	include ('shortcuts/footer.php');
	include ('libs/sqlclose.php');
?>
