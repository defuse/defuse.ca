﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
namespace GoodPasswordGenerator
{
    class passgen
    {
        public enum EncodingType
        {
            ASCII, ALPHA, HEX
        }
        const int PASSLENGTH = 64;
        const string ASCII = "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
        const string ALPHA = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        const string HEX = "0123456789ABCDEF";

        public bool WriteKeyfile(string filename)
        {
            byte[] keyfile = new byte[1024];
            GetRandom(ref keyfile);
            try
            {
                System.IO.File.WriteAllBytes(filename, keyfile);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public string GetPassword(EncodingType type)
        {
            byte[] random = new byte[128];
            GetRandom(ref random);
            switch (type)
            {
                case EncodingType.ALPHA:
                    return formatBytes(random, ALPHA.ToCharArray());
                case EncodingType.ASCII:
                    return formatBytes(random, ASCII.ToCharArray());
                case EncodingType.HEX:
                    return formatBytes(random, HEX.ToCharArray());
                default:
                    return "";
            }
        }
        //returns remainder of long division
        protected byte divide(ref byte[] number, ref byte[] quotient, byte divisor)
        {
            byte remainder = 0;
            int total = 0;
            for (int i = 0; i < number.Length; i++)
            {
                //special long division only works if divisor is <=byte sized
                total = (remainder * 256 + number[i]);
                quotient[i] = (byte)(total / divisor);
                remainder = (byte)(total % divisor);
            }
            return remainder;
        }

        protected string formatBytes(byte[] random, char[] set)
        {
            string result = "";
            for (int i = 0; i < PASSLENGTH; i++)
            {
                result += set[ divide(ref random, ref random, (byte)set.Length)];
            }
            return result;
        }
        protected void GetRandom(ref byte[] fill)
        {
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            rng.GetBytes(fill);
        }
    }
}
