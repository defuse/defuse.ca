﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GoodPasswordGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            passgen pass = new passgen();
            this.txtHex.Text = pass.GetPassword(passgen.EncodingType.HEX);
            this.txtAlpha.Text = pass.GetPassword(passgen.EncodingType.ALPHA);
            this.txtAscii.Text = pass.GetPassword(passgen.EncodingType.ASCII);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                passgen pass = new passgen();
                if (!pass.WriteKeyfile(dlg.FileName))
                {
                    MessageBox.Show("There was an error saving the file.", "Error");
                }
                else
                {
                    MessageBox.Show("Keyfile saved at: " + dlg.FileName);
                }
            }
        }
    }
}
