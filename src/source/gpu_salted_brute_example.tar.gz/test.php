<?php
	echo md5("http://ossbox.com");
?>

