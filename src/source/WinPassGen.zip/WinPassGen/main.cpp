/*
 *  WinPassGen - Ultra-Secure Offline Password Generator for Windows.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 *  SECURITY:
 *    - Entropy is collected from the system CSPRNG, mouse movements, 64 bit ultra-high precision timer, etc.
 *    - Entropy is mixed into a 160-byte pool with SHA256.
 *    - The entropy pool is mixed then a "base conversion" algorithm is applied to obtain an unbiased password.
 */

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>
#include <wincrypt.h>
#include <tchar.h>
#include <intrin.h>
#include <psapi.h>
#include <queue>
#include "resource.h"
extern "C" {
#include "sha256.h"
}
#pragma intrinsic(__rdtsc)

#define POOL_SIZE 160

HINSTANCE hInst;
HWND hDialog;

sha256_context newEntropy;
HANDLE mouseRandMutex;
unsigned int pos = 0;
unsigned char* pool;
unsigned int mixCount = 0;
bool frozen;

// Applies the mixing function to the pool.
void Mix()
{
    unsigned char poolHash[32];
    for(int i = 0; i < POOL_SIZE; i+= 32)
    {
        sha256_context sha256;
        sha256_starts(&sha256);
        sha256_update(&sha256, pool, POOL_SIZE);
        sha256_finish(&sha256, poolHash);
        for(int j = 0; j < 32; j++)
            pool[i+j] ^= poolHash[j];
    }
    mixCount++;
}

// Inserts entropy into the pool and mixes the pool.
void Mixin(void* data, unsigned int size)
{
    for(int i = 0; i < size; i++)
    {
        pool[pos] += ((unsigned char*)data)[i];
        pos = (pos + 1) % POOL_SIZE;
        if(pos == 0) //Mix the pool if we've reached the end
            Mix();
    }
    Mix();
}

// Mixes randomness into the pool then converts the state of the pool to a password.
// pass - out - buffer to store the password.
// charSet - in - null-terminated string of acceptable characters.
void PoolToPass(TCHAR pass[65], LPTSTR charSet)
{
    //Mix in known-good randomness per-password just to be safe.
    HCRYPTPROV hCryptCtx = NULL;
    CryptAcquireContext(&hCryptCtx, NULL, MS_DEF_PROV, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT);
    unsigned char rand[32];
    CryptGenRandom(hCryptCtx, 32, rand);
    CryptReleaseContext(hCryptCtx, 0);
    __int64 time = __rdtsc();
    Mixin((void*)&time, sizeof(__int64));
    Mixin((void*)&rand, 64);
    Mix();

    //The following is just a base conversion algorithm.
    unsigned char tmp[POOL_SIZE];
    unsigned char quotient[POOL_SIZE];
    memcpy(tmp, pool, POOL_SIZE);

    unsigned int remainder = 0;
    unsigned int total = 0;
    unsigned int divisor = _tcslen(charSet);
    for(int i = 0; i < 64; i++)
    {
        for(int j = 0; j < POOL_SIZE; j++)
        {
            total = (remainder * 256) + tmp[j];
            quotient[POOL_SIZE - j - 1] = total / divisor;
            remainder = total % divisor;
        }
        memcpy(tmp, quotient, POOL_SIZE);
        pass[i] = charSet[remainder];
    }
    pass[64] = 0;

    //Get rid of the data that was used to generate the password.
    Mix();
}

// Updates the GUI with new passwords.
void UpdatePasswords()
{
    TCHAR pass[65];

    PoolToPass(pass, TEXT("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890~`!@#$%^&*()-_=+{[}]|\\:;\"'<,>.?/"));
    SetDlgItemText(hDialog, IDC_ASCII, (LPCTSTR)&pass);

    PoolToPass(pass, TEXT("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"));
    SetDlgItemText(hDialog, IDC_ALPHANUM, (LPCTSTR)&pass);

    PoolToPass(pass, TEXT("0123456789ABCDEF"));
    SetDlgItemText(hDialog, IDC_HEX, (LPCTSTR)&pass);
}

// Background thread entrypoint.
// This thread's purpose is to periodically mix in the entropy provided by the UI thread,
// mix in entropy from the Windows CSPRNG, and rapidly change the passwords displayed on the UI.
DWORD Mixer(LPVOID lpdwThreadParam)
{
    HCRYPTPROV hCryptCtx = NULL;
    CryptAcquireContext(&hCryptCtx, NULL, MS_DEF_PROV, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT);
    while(true)
    {
        if(WaitForSingleObject(mouseRandMutex, INFINITE) == WAIT_OBJECT_0)
        {
            unsigned char sha256[32];
            sha256_finish(&newEntropy, sha256);
            sha256_starts(&newEntropy);
            Mixin(sha256, 32);
        }
        ReleaseMutex(mouseRandMutex);

        unsigned char rand[32];
        CryptGenRandom(hCryptCtx, 32, rand);
        __int64 time = __rdtsc();
        Mixin((void*)&time, sizeof(__int64));
        Mixin((void*)&rand, 32);

        PROCESS_MEMORY_COUNTERS_EX memInfo;
        HANDLE currentProcess = GetCurrentProcess();
        GetProcessMemoryInfo(currentProcess, (PROCESS_MEMORY_COUNTERS*)&memInfo, sizeof(PROCESS_MEMORY_COUNTERS_EX));
        Mixin((void*)&memInfo, sizeof(PROCESS_MEMORY_COUNTERS_EX));

        if(!frozen)
        {
            UpdatePasswords();
        }
        SetDlgItemInt(hDialog, IDC_POOLMIX, mixCount, FALSE);
        Sleep(20);
    }
}

BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    // Add all messages to the entropy pool.
    if(WaitForSingleObject(mouseRandMutex, INFINITE) == WAIT_OBJECT_0)
    {
        unsigned __int64 time = __rdtsc();
        sha256_update(&newEntropy, (unsigned char*)&time, sizeof(unsigned __int64));
        sha256_update(&newEntropy, (unsigned char*)&uMsg, sizeof(UINT));
        sha256_update(&newEntropy, (unsigned char*)&wParam, sizeof(WPARAM));
        sha256_update(&newEntropy, (unsigned char*)&lParam, sizeof(LPARAM));
    }
    ReleaseMutex(mouseRandMutex);

    switch(uMsg)
    {
        case WM_INITDIALOG:
        {
            hDialog = hwndDlg;

            HFONT fixedWidth = CreateFont(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, TEXT("Courier"));
            SendMessage(GetDlgItem(hwndDlg, IDC_ASCII), WM_SETFONT, (WPARAM)fixedWidth , TRUE);
            SendMessage(GetDlgItem(hwndDlg, IDC_ALPHANUM), WM_SETFONT, (WPARAM)fixedWidth , TRUE);
            SendMessage(GetDlgItem(hwndDlg, IDC_HEX), WM_SETFONT, (WPARAM)fixedWidth , TRUE);

            HICON hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1));
            SendMessage(hwndDlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
            return TRUE;
        }
        case WM_CLOSE:
            EndDialog(hwndDlg, 0);
            return TRUE;

        case WM_MOUSEMOVE:
            if(WaitForSingleObject(mouseRandMutex, INFINITE) == WAIT_OBJECT_0)
            {
                //The entropy has already been added above, so this is just for show.
                SetDlgItemInt(hwndDlg, IDC_XVAL, GET_X_LPARAM(lParam), FALSE);
                SetDlgItemInt(hwndDlg, IDC_YVAL, GET_Y_LPARAM(lParam), FALSE);
                unsigned __int64 time = __rdtsc();
                char textBuf[30];
                _i64toa_s(time, textBuf, 30, 10);
                SetDlgItemText(hwndDlg, IDC_TIMER, (LPCSTR)textBuf);
            }
            ReleaseMutex(mouseRandMutex);
        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                case IDC_FREEZE:
                if(HIWORD(wParam) == BN_CLICKED)
                {
                    frozen = !frozen;
                    if(frozen)
                    {
                        SetDlgItemText(hwndDlg, IDC_FREEZE, "Unfreeze");
                    }
                    else
                    {
                        SetDlgItemText(hwndDlg, IDC_FREEZE, "Freeze");
                    }
                }
                break;
            }
    }

    return FALSE;
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
    hDialog = NULL;
    hInst = hInstance;
    frozen = false;
    pool = new unsigned char[POOL_SIZE];
    mouseRandMutex = CreateMutex(NULL, FALSE, NULL);
    sha256_starts(&newEntropy);
    HANDLE hBgThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)&Mixer, NULL, 0, NULL);
    INT_PTR res = DialogBox(hInstance, MAKEINTRESOURCE(DLG_MAIN), NULL, (DLGPROC)DialogProc);
    TerminateThread(hBgThread, 0);
    CloseHandle(mouseRandMutex);
    delete[] pool;
    return res;
}


