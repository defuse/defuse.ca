#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define DLG_MAIN                                101
#define IDI_ICON1                               102
#define IDC_ASCII                               1004
#define IDC_ALPHANUM                            1005
#define IDC_HEX                                 1006
#define IDC_FREEZE                              1007
#define IDC_MOUSERAND                           1014
#define IDC_XVAL                                1015
#define IDC_YVAL                                1017
#define IDC_TIMER                               1018
#define IDC_POOLMIX                             1019
