﻿using System;
using System.Collections.Generic;

namespace PolyThread
{
    public interface ProcessingJob
    {
        void Compute();
    }
    public class JobManager<job> where job : ProcessingJob
    {
        private int tmpnumjobs = 0;
        public enum ProcessingState
        {
            Processing, //stuff is being processed still accepting new jobs
            Waiting, //all jobs are finished, waiting for more jobs, will continue to run when new jobs are added
            Stopped,	//hasnt been started or was explicitly stopped, accepts new jobs but doesnt process them until started
            WaitStop //waiting to be stopped
        }

        public delegate void JobFinishedReturn(object sender, job finished);
        public delegate void AllJobsFinishedReturn(object sender, job[] finished);
        public delegate void WaitStopCompleteReturn(object sender);

        private object eventlocker = new object();

        //events
        public event JobFinishedReturn JobCompleted;
        public event AllJobsFinishedReturn AllJobsCompleted;
        public event WaitStopCompleteReturn SoftStopFinished;

        ThreadMgr<job>[] threads;
        private ProcessingState state;

        private bool allcompletecalled = false;

        public JobManager(int numThreads)
        {
            if (numThreads < 1)
                Error("Cannot have a negative or zero number of threads.");
            state = ProcessingState.Stopped;
            threads = new ThreadMgr<job>[numThreads];
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i] = new ThreadMgr<job>();
                threads[i].JobCompleted += JobFinished;
                threads[i].WaitStopCompleted += WStopComplete;
                threads[i].QueueCompleted += QueueCompleted;
            }
        }

        //for the addjobs, remember to start the threadmanagers if they have stopped (or make them have a waiting status that just waits for more jobs)
        public void AddJob(job[] toAdd)
        {
            tmpnumjobs += toAdd.Length;
            allcompletecalled = false;
            for (int i = 0; i < toAdd.Length; i++)
            {
                int low = FindLowest(threads);
                threads[low].Add(toAdd[i]);
            }
        }

        public void AddJob(job toAdd)
        {
            allcompletecalled = false;
            int lowestindex = FindLowest(threads);
            //the thread should handle starting automatically
            threads[lowestindex].Add(toAdd);
            tmpnumjobs++;
        }


        //TODO: make sure we handle the internal threadmanager states corectly
        public job[] StartProcessingBlocking()
        {
            allcompletecalled = false;
            //start a blocking processing operation, return the completed jobs
            //todo: error handling
            //todo: maintain state
            if (state != ProcessingState.Stopped)
                Error("JobManager is already processing!");
            state = ProcessingState.Processing;
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i].StartProcessing();
            }

            for (int i = 0; i < threads.Length; i++)
            {
                threads[i].WaitForComplete();
                threads[i].Stop(true);
            }

            List<job> finished = new List<job>();
            for (int i = 0; i < threads.Length; i++)
            {
                foreach (job x in threads[i].GetCompleted())
                {
                    finished.Add(x);
                }
            }
            state = ProcessingState.Stopped;
            return finished.ToArray();
        }

        public void StartProcessing()
        {
            allcompletecalled = false;
            if (state != ProcessingState.Stopped)
                Error("JobManager is already processing!");
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i].StartProcessing();
            }
            state = ProcessingState.Processing;
        }

        public void StopProcessing(bool force)
        {
            allcompletecalled = false;
            //gently stop processing (wait for last jobs to finish) or force them to stop
            //make sure we dont loose a job when we force stop

            //if not force, set status to waitstop then set to stop when finished
            for (int i = 0; i < threads.Length; i++)
                threads[i].Stop(force);
            if (!force)
                state = ProcessingState.WaitStop;
        }

        public void BlockUntilComplete()
        {
            while (tmpnumjobs > 0)
            {
                System.Threading.Thread.Sleep(100);
            }
        }

        public ProcessingState GetState()
        {
            return state;
        }

        #region Helper Methods

        private int FindLowest(ThreadMgr<job>[] haystack)
        {
            int lowest = -1;
            int lowestindex = -1;
            for (int i = 0; i < haystack.Length; i++)
            {
                if (haystack[i].NumJobs() < lowest || lowest == -1)
                {
                    lowest = haystack[i].NumJobs();
                    lowestindex = i;
                }
            }
            return lowestindex;
        }


        //our event callback
        private void JobFinished(object sender, job x)
        {
            tmpnumjobs--;
            if (JobCompleted != null)
            {
                lock (eventlocker)
                    JobCompleted(this, x);
            }

        }

        //remember these events ARE NOT thread safe
        private void QueueCompleted(object sender)
        {
            //distribute jobs to newly finished thread
            /*ThreadMgr<job> lowest = (ThreadMgr<job>)sender;
            int i = 0;
            if((i = FindHighest(threads)) != -1)
            {
                //System.Windows.Forms.MessageBox.Show("jksdjflsd" + threads[i].GetState().ToString());
                lowest.Add(threads[i].TakeJob());
                return;
            }*/

            lock (eventlocker)
            {
                if (!allcompletecalled && AllCompleted(threads))
                {
                    state = ProcessingState.Waiting;
                    allcompletecalled = true;
                    if (AllJobsCompleted != null)
                    {
                        AllJobsCompleted(this, GetAllFinished(threads));
                    }
                }
            }

        }
        private int FindHighest(ThreadMgr<job>[] haystack)
        {
            int highest = 0;
            int highestindex = -1;
            for (int i = 0; i < haystack.Length; i++)
            {
                if (haystack[i].NumJobs() > highest)
                {
                    highest = haystack[i].NumJobs();
                    highestindex = i;
                }
            }
            return (highest == 0 ? -1 : highestindex);
        }
        private void WStopComplete(object sender)
        {
            int i = 0;
            for (i = 0; i < threads.Length && threads[i].GetState() == ThreadMgr<job>.ThreadState.Stopped; i++) ;
            if (i == threads.Length - 1)
            {
                state = ProcessingState.Stopped;
                lock (eventlocker)
                    SoftStopFinished(this);
            }
        }

        private job[] GetAllFinished(ThreadMgr<job>[] toGet)
        {
            List<job> all = new List<job>();
            for (int i = 0; i < toGet.Length; i++)
            {
                job[] forThread = toGet[i].GetCompleted();
                foreach (job j in forThread)
                    all.Add(j);
            }
            return all.ToArray();
        }

        private bool AllCompleted(ThreadMgr<job>[] check)
        {
            int i = 0;
            for (i = 0; i < check.Length && check[i].GetState() == ThreadMgr<job>.ThreadState.Waiting; i++) ;
            return i == check.Length;
        }

        private void Error(string msg)
        {
            throw new Exception(msg);
        }

        #endregion
    }
}
