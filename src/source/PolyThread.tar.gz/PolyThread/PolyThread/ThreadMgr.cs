﻿
using System;
using System.Threading;
using System.Collections.Generic;

namespace PolyThread
{
    class ThreadMgr<job> where job : ProcessingJob
    {
        public delegate void ThreadJobCompleted(object sender, job finished);
        public delegate void QueueComplete(object sender);
        public delegate void WaitStopCompleteCallback(object sender);

        private object eventlocker = new object();

        public event ThreadJobCompleted JobCompleted;
        public event QueueComplete QueueCompleted;
        public event WaitStopCompleteCallback WaitStopCompleted;

        private Thread t;
        private Queue<job> todo;
        private List<job> completed;
        private volatile ThreadState state;
        private volatile bool softStop;

        public enum ThreadState
        {
            Processing, Waiting, Stopped, WaitStop
        }

        public ThreadMgr()
        {
            t = new Thread(ProcessQueue);
            t.IsBackground = true;
            todo = new Queue<job>();
            completed = new List<job>();
            state = ThreadState.Stopped;
            softStop = false;
        }
        private void CallJobCompleted(object task)
        {
            if (JobCompleted != null)
            {
                lock (eventlocker)
                    JobCompleted(this, (job)task);
            }
        }
        private void CallQueueComplete()
        {
            if (QueueCompleted != null)
            {
                lock (eventlocker)
                    QueueCompleted(this);
            }
        }
        private void CallWaitStopComplete()
        {
            if (WaitStopCompleted != null)
            {
                lock (eventlocker)
                    WaitStopCompleted(this);
            }
        }
        private void ProcessQueue()
        {
            bool onefinished = true;
            object backup = null;
            job task;
            try
            {
                while (!softStop)
                {
                    lock (todo)
                    {
                        if (todo.Count <= 0) break;
                        task = todo.Dequeue();
                    }
                    onefinished = false;
                    lock (task)
                    {
                        backup = task;
                        task.Compute();
                    }
                    onefinished = true;
                    Thread t = new Thread(new ParameterizedThreadStart(CallJobCompleted));
                    t.Start((object)task);
                    lock (completed)
                    {
                        completed.Add(task);
                    }
                }
                FinishedQueue();
                return;
            }
            catch (ThreadAbortException ex)
            {
                //add the unifinished job to the queue so it doesnt get lost
                if (!onefinished && backup != null)
                    todo.Enqueue((job)backup);
                state = ThreadState.Stopped;
            }
        }

        private void FinishedQueue()
        {
            if (!softStop)
            {
                // this.t.Interrupt();
                state = ThreadState.Waiting;
                Thread t = new Thread(new ThreadStart(CallQueueComplete));
                t.Start();
            }
            else
            {
                WStopComplete();
            }
        }

        private void WStopComplete()
        {
            state = ThreadState.Stopped;
            Thread t = new Thread(new ThreadStart(CallWaitStopComplete));
            t.Start();
        }

        public void Add(job toAdd)
        {
            lock (todo)
                todo.Enqueue(toAdd);
            if (state == ThreadState.Waiting)
                StartThread();
        }

        public ThreadState GetState()
        {
            return state;
        }

        public job TakeJob()
        {
            lock (todo)
                return todo.Dequeue();
        }

        public int NumJobs()
        {
            lock (todo)
                return todo.Count;
        }

        public void StartProcessing()
        {
            if (state != ThreadState.Stopped)
                Error("Thread is already running!");
            StartThread();
        }

        private void StartThread()
        {
            softStop = false;
            state = ThreadState.Processing;
            t = new Thread(ProcessQueue);
            t.Start();
        }

        public void WaitForComplete()
        {
            t.Join();
        }

        public void Stop(bool force)
        {
            if (force)
            {
                t.Abort();
            }
            else
            {
                softStop = true;
                state = ThreadState.WaitStop;
            }
        }

        public job[] GetCompleted()
        {
            lock (completed)
                return completed.ToArray();
        }

        private void Error(string msg)
        {
            throw new Exception(msg);
        }
    }
}
