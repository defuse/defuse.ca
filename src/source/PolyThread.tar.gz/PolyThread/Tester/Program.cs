﻿using System;
using System.Collections.Generic;
using System.Text;
using PolyThread;

namespace Tester
{
    class Program
    {
        class SquareRooter : PolyThread.ProcessingJob
        {
            int _low;
            int _high;
            double _sum;
            public SquareRooter(int low, int high)
            {
                _low = low;
                _high = high;
            }

            public void Compute()
            {
                _sum = 0;
                for (int i = _low; i <= _high; i++)
                {
                    _sum += Math.Sqrt(i);
                }
            }

            public double GetSum()
            {
                return _sum;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Test for PolyThread library.");
            Console.WriteLine("Compute all square roots up to:");
            int maxRoot = int.Parse(Console.ReadLine());

            Console.WriteLine("Number of threads:");
            int numThreads = int.Parse(Console.ReadLine());


            JobManager<SquareRooter> mgr = new JobManager<SquareRooter>(numThreads);
            mgr.JobCompleted += new JobManager<SquareRooter>.JobFinishedReturn(mgr_JobCompleted);
            int share = maxRoot / numThreads;
            for (int i = 0; i < numThreads - 1; i++)
            {
                SquareRooter doRoot = new SquareRooter(i * share + 1, i * share + share);
                mgr.AddJob(doRoot);
            }
            mgr.AddJob(new SquareRooter( (numThreads - 1) * share + 1, maxRoot));
            mgr.StartProcessingBlocking();

            Console.WriteLine("All Done.");

            Console.ReadLine();
        }

        static void mgr_JobCompleted(object sender, Program.SquareRooter finished)
        {
            Console.WriteLine("Done: " + finished.GetSum());
        }
    }
}
