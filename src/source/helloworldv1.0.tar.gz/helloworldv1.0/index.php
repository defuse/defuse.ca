<?php
/*==============================================================================

		OSSBOX's Secure & Lightweight CMS in PHP for Linux.

	This code is hereby placed into the public domain by its author 
	FireXware. It may be freely used for any purpose whatsoever.

                      PUBLIC DOMAIN CONTRIBUTION NOTICE							 
   This work has been explicitly placed into the Public Domain for the
	benefit of anyone who may find it useful for any purpose whatsoever.

	This CMS is heavily dependant upon GRC's Script-Free Menuing System:
		        http://www.grc.com/menudemo.htm
	
==============================================================================*/

/*

You must have the following in your .htaccess file:

RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]

*/

//Strengthen the server's CSPRNG
$entropy = implode($_SERVER) . implode($_GET) . implode($_POST) . implode($_COOKIE) . implode($_ENV) . microtime() . mt_rand() . mt_rand();
file_put_contents("/dev/random", $entropy);

//Default title of the page (shown on the top of the window and on top of tabs)
$TITLE = "TITLE_TITLE_TITLE";

//Default meta info (for search engines)
$META_DESCRIPTION = "";
$META_KEYWORDS = "";


//name variable will contain the name of the page
$name = "";

//urls can be in any of the following forms:
// http://example.com/?page=test
// http://example.com/index.php?page=test
// http://example.com/test
// http://example.com/text.htm (all other forms will get directed to this form)
// http://example.com/index.php will be redirected to http://example.com/

//grab the name of the page the user wants from a URL variable
if(isset($_GET['page']))
{
	$name = $_GET['page'];
	header("HTTP/1.1 301 Moved Permanently");
	header("Location: $name.htm");
	die();
}
elseif ($_SERVER['REQUEST_URI'] != "/index.php")
{
	$name = substr($_SERVER['REQUEST_URI'], 1);
	if(strpos($name, "?") !== false)
	{
		$name = substr($name, 0, strpos($name, "?"));
	}
	if($name != "" && strpos($name, ".htm") === false)
	{
		header("HTTP/1.1 301 Moved Permanently");
		header("Location: $name.htm");
	}
	$name = str_replace(".htm", "", $name);
}
elseif($_SERVER['REQUEST_URI'] == "/index.php")
{
	header("HTTP/1.1 301 Moved Permanently");
	header("Location: /");
}

//folder where the pages are kept (relative to this script)
$root = "/var/www/release/pages/";

//used by scripts in other folders that call index.php
if(isset($dirmod))
	$root = $dirmod . $root;

//default path if no page is specified (aka home)
$path = "home.html";

//this is our firewall, we use a switch to turn the name of a page into the path where the .html content is located
//this protects us against RFI and LFI
switch($name)
{
	//Map each page name to the name of the file within the $root folder.
	//Also, set $commentid for each page, leave it as "" to disable comments for that page
	//Two pages may use the same commentid, they will show the same set of comments.
	case "":
		$name = "home";
		$path = "home.html";
		break;
	case "home":
		$path = "home.html";
		break;
	case "about":
		$path = "about.html";
		$META_DESCRIPTION = "About OSSBox.";
		break;
	default: //page name wasn't valid. 404 and exit
		$name = ""; // destroy any possibly bad user input asap.
		header("HTTP/1.0 404 Not Found");
		header("Status: 404 Not Found");
		$path = "404.html";
		break;
}

//combine the folder and the name of the file within the folder to create the full name
$fullpath = $root . $path;


//handles when the user adds a comment

if(isset($_POST['submit']) && !empty($commentid))
{
	$commentname = sqlsani(smartslashes($_POST['name']));
	if(empty($commentname))
		$commentname = "Anonymous";
	$comment = sqlsani(smartslashes($_POST['comment']));
	mysql_query("INSERT INTO comments (name, comment, commentid) VALUES('$commentname', '$comment', '$commentid')");
}

//-----SECURITY AND HELPER FUNCTIONS----//

//XSS sanitize, makes sure $data can be printed on the screen without any chance of XSS
//returns sanitized string
function xsssani($data)
{
	$data = htmlspecialchars($data, ENT_QUOTES);
	$data = str_replace("\r\n", "<br />", $data);
	$data = str_replace("\n", "<br />", $data);
	$data = str_replace("\r", "<br />", $data);
	return $data;
}

//SQL sanitize, makes sure that $data is safe to use in a mysql query
//returns the sanitized string
function sqlsani($data)
{
	return mysql_real_escape_string($data);
}

//checks whether smart slashes are enabled and removes them if they are
function smartslashes($data)
{
	if(get_magic_quotes_gpc())
	{
		return stripslashes($data);
	}
	else
	{
		return $data;
	}
}

//Finally display the page:
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<title><?php echo $TITLE; ?></title>
<meta name="description" content="<?php echo $META_DESCRIPTION; ?>" />
<meta name="keywords" content="<?php echo $META_KEYWORDS; ?>" />
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<link rel="stylesheet" media="all" type="text/css" href="/mainmenu.css" />
<link rel="stylesheet" media="all" type="text/css" href="/main.css" />

</head>
<body>

<!-- This menuing system was made by Steve Gibson at GRC.COM 
			see more at http://www.grc.com/menudemo.htm -->

<!-- ########################## GRC Masthead Menu ########################## -->

<div class="menuminwidth0"><div class="menuminwidth1"><div class="menuminwidth2">
<div id="masthead">

	<h2>Header</h2>
</div>

<div class="menu">

<ul>
	<li class="headerlink" ><a href="/">Home<!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lt IE 7]><table border="0" cellpadding="0" cellspacing="0"><tr><td><![endif]-->
		<ul class="leftbutton">

			<li><a href="/about.htm">&nbsp;About</a></li>
			<li><a href="#">&nbsp;Blah..</a></li>
			<li><a href="#">&nbsp;Blah..</a></li>
		</ul>
		<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	</li>
</ul>

<ul>
	<li class="headerlink" ><a href="#">Blah..<!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lt IE 7]><table border="0" cellpadding="0" cellspacing="0"><tr><td><![endif]-->
		<ul>
			<li><a href="#">&nbsp;Blah..</a></li>
			<li><a href="#">&nbsp;Blah..</a></li>

		</ul>
	<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	</li>
</ul>


<ul>
	<li class="headerlink" ><a href="#">Blah..<!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lt IE 7]><table border="0" cellpadding="0" cellspacing="0"><tr><td><![endif]-->
		<ul>
			<li><a href="#">&nbsp;Blah..</a></li>
			<li><a href="#">&nbsp;Blah..</a></li>
			<li><a href="#"><span class="drop"><span>Blah..</span>&raquo;</span><!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lt IE 7]><table border="0" cellpadding="0" cellspacing="0"><tr><td><![endif]-->
				<ul>
					<li><a href="#">&nbsp;Blah..</a></li>
					<li><a href="#">&nbsp;Blah..</a></li>
				</ul>

				<!--[if lte IE 6]></td></tr></table></a><![endif]-->
			</li>

		</ul>
		<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	</li>
</ul>


</div> <!-- close "menu" div -->
<hr style="display:none" />
</div></div></div> <!-- close the "minwidth" wrappers -->
<!-- ###################### END OF GRC MASTHEAD MENU  ###################### -->
<div id="undergrad"></div>
<div id="content" style="margin: 0 auto; width: 80%; padding-top:20px;">
<?php
	//displays the page
	//not vulnerable to LFI or RFI, as all of filepath came from constant strings hard-coded into this script.
	if(file_exists($fullpath))
	{
		include($fullpath);
	}
	echo "<br /><br /><br />";
?>

</div>

</body>
</html>
