#ifndef _MISC_H
# define _MISC_H

char *sockaddrstr(const struct sockaddr *);

#endif
