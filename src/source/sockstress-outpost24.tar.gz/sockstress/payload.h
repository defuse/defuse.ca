#ifndef _PAYLOAD_H
# define _PAYLOAD_H

char *get_payload(uint16_t /* port */, uint32_t /* ip */, char * /* hostname */);

#endif
