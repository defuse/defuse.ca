/*
 *  main.cpp - SimpPSK implementation demo
 *  Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
 *
 *  Created and maintained by: FireXware  (OSSBox.com)
 *  Contact: firexware@gmail.com (If you need help, I certainly will if I have the time)
 *
 *  Copyright (C) 2010  FireXware
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <iostream>

#include "SimpPSK/SimpPSKClient.h"
#include "SimpPSK/SimpPSKServer.h"

using namespace std;

void PrintHex(unsigned int num)
{
    if(num < 10)
        cout << num;
    else
    {
        cout << (char)('A' + num - 10);
    }
}

void DumpBytes(unsigned char* bytes, unsigned int len)
{
    cout << "Length: " << len << "\n";
    for(unsigned int i = 0; i < len; i+= 32)
    {
        for(unsigned int j = 0; j < 32 && j+i < len; j++)
        {
            PrintHex(bytes[i+j] >> 4);
            PrintHex(bytes[i+j] % 16);
        }
        cout << "\n";
    }
    cout << "\n\n";
}

int main()
{
    //In this demonstration code, we are pretending that the client and server are being used within one function
    //This will never happen in real use, the data is going to be sent back and forth between machiens
    //I will try to distinguish as clear as possible the code running on the client vs server code.
    //It's also possible that this may be used with non-blocking sockets, but this example should still help.

    //before we get going, lets just declare some pointers we'll be using to hold our data that gets sent back and forth
    unsigned char* part1 = NULL;
    unsigned char* part2 = NULL;
    unsigned char* part3 = NULL;

    //SERVER
    unsigned char serverPassword[] = "DemoCodePassw0rd!"; //pretend this is the secret key the server has
    SimpPSKServer server(serverPassword, 17, HVER_SHA256); //use SHA256 as the hash if the client supports it
    server.SetAllowedHashTypes(false, false, true); //allow SHA256 to be used
    server.SetAllowedCipherTypes(true,true,true);
    //CLIENT
    unsigned char clientPassword[] = "DemoCodePassw0rd!"; //pretend this is the secret key the client has
    SimpPSKClient client(clientPassword, 17);
    client.SetAllowedHashTypes(true,true, true);
    client.SetAllowedCipherTypes(true,true,true);

    int len = 0; //we're just going to use this var. as a temp place to keep the length of the arrays

    try
    {
        part1 = client.StartAuthRequest(len);
    }
    catch (int err)
    {
        switch(err)
        {
        case BADSTATE_START_AUTH_REQUEST:
            //This would only happen if you didn't call this function at the right time, like after the 3-way handshake is already finished.
            break;
        }
        return -1;
    }
    DumpBytes(part1, len);
    //NOW - the client code sends "part1" to the server somehow... (remember to delete[] part1 in your code)
    //NOTE ABOUT SENDING: it is very likely that the handshake data will contain null bytes, so if however you are implementing sockets relies on null terminated strings, you must ASCII armor these parts.

    //SERVER
    //the server now has part1

    try
    {
        server.AcceptAuthRequest(part1, len);
        delete[] part1;
        part2 = server.GetAuthReply(len);
    }
    catch(int err)
    {
        cout << "fail" << err;;
        switch(err)
        {
        case INVALID_DATA:
            //this happens if the data recived from the client is incomplete. It would happen if the length isn't as big as expected.
            break;
        case NO_HASH_AGREEMENT:
            //This happens when the support (or isn't allowed to use) any of the hash algorithms the client supports
            //This could be the result of using an old client with a much newer service, or malicious packet tampering
            //I would just drop the connection here.
            break;
        case BADSTATE_START_AUTH_REQUEST:
            //This would only happen if you didn't call this function at the right time, like after the 3-way handshake is already finished.
            break;
        }
        return -1;
    }
    DumpBytes(part2,len);
    //so now we have part 2, we must send it to the client, remember to delete[] part2 in your code

    //CLIENT

    try
    {
        client.AcceptAuthReply(part2, len);
        delete[] part2;
        part3 = client.GetAuthFinalize(len);
    }
    catch(int err)
    {
        switch(err)
        {
        case INVALID_DATA:
            //this happens if the data recived from the client is incomplete. It would happen if the length isn't as big as expected.
            break;
        case NO_HASH_AGREEMENT:
            //This happens when the support (or isn't allowed to use) any of the hash algorithms the client supports
            //This could be the result of using an old client with a much newer service, or malicious packet tampering
            //I would just drop the connection here.
            break;
        case BADSTATE_START_AUTH_REQUEST:
            //This would only happen if you didn't call this function at the right time, like after the 3-way handshake is already finished.
            break;
        }
        return -1;
    }
    DumpBytes(part3,len);
    //Now we send part3 to the server, again remember to delete[] part3

    //SERVER

    try
    {
        server.AcceptAuthFinalize(part3,len);
        delete[] part3;
    }
    catch(int err)
    {
        switch(err)
        {
        case BADSTATE_START_AUTH_REQUEST:
            //This would only happen if you didn't call this function at the right time, like before the 3-way handshake had started
            break;
        }
        return -1;
    }

    //WHEW! that's it. Now with any luck all will have gone well, and both clients will have established an equivalent session key.
    //we can verify this using the ValidAuthentication() method

    //SERVER (still)
    try
    {
        if(server.ValidAuthentication())
        {
            //YAY the server now knows that he's talking to the right client, assuming nobody else knows the shared key.
            //we can get the session key to use for encryption..
            unsigned char* sessionKey = server.GetSessionKey(len); // =]
            //use the session key
            DumpBytes(sessionKey,len);
            delete[] sessionKey; //remember to do that :P
        }
        else
        {
            //something went wrong, either they have different shared keys or there is someone messing with the connection
            //best thing to do would be to just kill the connection
        }
    }
    catch (int err)
    {
        switch(err)
        {
        case BADSTATE_START_AUTH_REQUEST:
            //This would only happen if you didn't call this function at the right time, like before the 3-way handshake was finished
            break;
        }
        return -1;
    }

    //now we do the same thing on the client

    //CLIENT
    try
    {
        if(client.ValidAuthentication())
        {
            //YAY the client now knows that he's talking to the right server, assuming nobody else knows the shared key.
            //we can get the session key to use for encryption..
            unsigned char* sessionKey = client.GetSessionKey(len); // =]
            //use the session key
            DumpBytes(sessionKey,len);
            delete[] sessionKey; //remember to do that :P

        }
        else
        {
            //something went wrong, either they have different shared keys or there is someone messing with the connection
            //best thing to do would be to just kill the connection
        }
    }
    catch (int err)
    {
        switch(err)
        {
        case BADSTATE_START_AUTH_REQUEST:
            //This would only happen if you didn't call this function at the right time, like before the 3-way handshake was finished
            break;
        }
        return -1;
    }
}

/*
int main()
{
    //ATTACK DETECTION TESTING:
    //0 - no attack
    //1 - client salt change
    //2 - client challenge change
    //3 - server salt change
    //4 - server response change
    //5 - server challenge change
    //6 - client response change
    //7 - wrong password
    //8 - attacker lowers security version
    int attack = 0;

    unsigned char cPassword[7] = "ABCDEF";
    unsigned char sPassword[7] =  "ABCDEF";

    cout << "Client Password: \n";
    DumpBytes(cPassword,6);

    cout << "Server Password: \n";
    DumpBytes(cPassword,6);

    if(attack == 7)
    {
        cPassword[0] += 1;
    }
  try{

        SimpPSKClient client(cPassword, 6, HVER_SHA256);
        SimpPSKServer server(sPassword, 6);

        int len = 0;

        unsigned char* authRequest = client.StartAuthRequest(len);

        cout << "AuthRequest: \n";
        DumpBytes(authRequest, len);

        if(attack == 1)
        {
            authRequest[0] += 1;
        }

        if(attack == 2)
        {
            authRequest[40] += 1;
        }

        if(attack == 8)
        {
            authRequest[len - 1] = HVER_SHA256 - 1;
        }

        server.AcceptAuthRequest(authRequest, len);

        delete[] authRequest;
        unsigned char* authReply = server.GetAuthReply(len);

        cout << "AuthReply: \n";
        DumpBytes(authReply, len);

        if(attack == 3)
        {
            authReply[0] += 1;
        }

        if(attack == 4)
        {
            authReply[40] += 1;
        }

        if(attack == 5)
        {
            authReply[70] += 1;
        }

        client.AcceptAuthReply(authReply, len);
        delete[] authReply;

        unsigned char* authFinalize = client.GetAuthFinalize(len);

        cout << "AuthFinalize: \n";
        DumpBytes(authFinalize, len);

        if(attack == 6)
        {
            authFinalize[0] += 1;
        }

        server.AcceptAuthFinalize(authFinalize, len);
        delete[] authFinalize;
        if(server.ValidAuthentication())
        {
            cout << "SERVER SAYS: VALID!\n";
            cout << "SESSION KEY: \n";
            unsigned char* key = server.GetSessionKey(len);
            DumpBytes(key, len);
            delete[] key;
        }
        else
        {
            cout << "SERVER SAYS: FAYUL!\n";
        }

        if(client.ValidAuthentication())
        {
            cout << "CLIENT SAYS: VALID!\n";
            cout << "SESSION KEY: \n";
            unsigned char* key = client.GetSessionKey(len);
            DumpBytes(key, len);
            delete[] key;
        }
        else
        {
            cout << "CLIENT SAYS: FAYUL!\n";
        }
    }
    catch (int err)
    {
        cout << "ERROR #" << err << ": " << SimpPSK::GetErrorMessage(err);
    }

    return 0;
}
*/
