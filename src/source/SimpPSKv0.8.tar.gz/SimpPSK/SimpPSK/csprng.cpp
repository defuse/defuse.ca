/*
 *  csprng.cpp - a cross platform (windows and *nix) CSPRNG
 *  Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
 *
 *  Created and maintained by: FireXware  (OSSBox.com)
 *  Contact: firexware@gmail.com (If you need help, I certainly will if I have the time)
 *
 *  Copyright (C) 2010  FireXware
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/


#ifndef CSPRNG_H
#define CSPRNG_H

#ifdef _WIN32
    #include <Windows.h>
    #include <Wincrypt.h>
#else
    #include <fstream> //for reading from /dev/urandom on *nix systems
#endif

#include "constants.h"

class CSPRNG
{
public:
    static void FillRandom(unsigned char buf[], unsigned int bufLength)
    {
        #ifdef _WIN32
            //WIN32 CSPRNG thanks to: http://www.tomhandal.com/DevBlog/2010/03/17/cryptographically-random-bytes-in-microsoft-windows/
            HCRYPTPROV hCryptCtx = NULL;
            CryptAcquireContext(&hCryptCtx, NULL, MS_DEF_PROV, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT);
            CryptGenRandom(hCryptCtx, bufLength, buf);
            CryptReleaseContext(hCryptCtx, 0);
        #else
            std::ifstream devRand ("/dev/urandom", std::ios::in | std::ios::binary);
            bool suc = devRand.read((char*)buf,bufLength);
            devRand.close();
            if(!suc)
                throw RNG_FAIL;
        #endif
    }

};



#endif // CSPRNG_H

