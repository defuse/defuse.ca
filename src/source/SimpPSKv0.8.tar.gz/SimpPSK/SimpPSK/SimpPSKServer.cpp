/*
 *  SimpPSKServer.cpp - the server part of SimpPSK
 *  Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
 *
 *  Created and maintained by: FireXware  (OSSBox.com)
 *  Contact: firexware@gmail.com (If you need help, I certainly will if I have the time)
 *
 *  Copyright (C) 2010  FireXware
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "SimpPSKServer.h"

#include "csprng.cpp"
#include "crypto.cpp"
#include <string.h>

SimpPSKServer::SimpPSKServer(unsigned char key[], unsigned int keyLength, unsigned char preferredHash, unsigned char preferredCipher)
: SimpPSK(key,keyLength)
{
    _allocatedHashDependantData = false;
    _preferredHash = preferredHash;
    _preferredCipher = preferredCipher;
}

void SimpPSKServer::AcceptAuthRequest(unsigned char authRequest[], unsigned int requestLength)
{
    //<client salt> . <client challenge>
    if(!(requestLength >= 2 * RANDOM_SEED_BYTE_LENGTH + 1))
        throw INVALID_DATA;
    if(this->_state == STATE_NONE)
    {
        this->_state = STATE_SERVER_GOT_AUTH;

        CSPRNG::FillRandom(_serverRandomSalt, RANDOM_SEED_BYTE_LENGTH);

        memcpy(this->_clientRandomSalt, authRequest, RANDOM_SEED_BYTE_LENGTH);
        memcpy(this->_clientChallenge, authRequest + RANDOM_SEED_BYTE_LENGTH, RANDOM_SEED_BYTE_LENGTH);

        int numHashes = authRequest[2 * RANDOM_SEED_BYTE_LENGTH];

        if(requestLength < 2 * RANDOM_SEED_BYTE_LENGTH + 1 + numHashes)
            throw INVALID_DATA;
        unsigned char allowedHashes[numHashes];
        memcpy(allowedHashes, authRequest + 1 + 2 * RANDOM_SEED_BYTE_LENGTH, numHashes);

        int numCiphers = authRequest[2 * RANDOM_SEED_BYTE_LENGTH + 1 + numHashes];
        unsigned char allowedCiphers[numCiphers];
        memcpy(allowedCiphers, authRequest + 2 * RANDOM_SEED_BYTE_LENGTH + 1 + numHashes + 1, numCiphers);

        _currentCipherVersion = GetBestCipherVersion(allowedCiphers, numCiphers, _preferredCipher, _allowAES256, _allowSERPENT256, _allowTWOFISH256);

        _currentHashVersion = GetBestHashVersion(allowedHashes, numHashes, _preferredHash, _allowSHA256, _allowWHIRLPOOL, _allowSHA512);
        SECURE_HASH_LENGTH = Crypto::GetHashLength(_currentHashVersion);

        _clientResponse = new unsigned char[SECURE_HASH_LENGTH];
        _serverResponse = new unsigned char[SECURE_HASH_LENGTH];
        _allocatedHashDependantData = true;

        CreateSessionKey();
    }
    else
    {
        throw BADSTATE_ACCEPT_AUTH_REQUEST;
    }
}

unsigned char* SimpPSKServer::GetAuthReply(int& len)//server
{
    //<server salt> . <server (challenge) response> . <server challenge>
    if(this->_state == STATE_SERVER_GOT_AUTH)
    {
        this->_state = STATE_SERVER_SENT_AUTH_REPLY;

        len = 2 + RANDOM_SEED_BYTE_LENGTH + SECURE_HASH_LENGTH + RANDOM_SEED_BYTE_LENGTH;
        unsigned char* authReply = new unsigned char[len];
        //randomsalt,challengeresponse
        unsigned char responseBuffer[SESSION_KEY_LENGTH + RANDOM_SEED_BYTE_LENGTH]; //sessionkey . challenge
        memcpy(responseBuffer , this->_sessionKey, SESSION_KEY_LENGTH);
        memcpy(responseBuffer + SESSION_KEY_LENGTH, this->_clientChallenge, RANDOM_SEED_BYTE_LENGTH);

        unsigned char challengeResponse[SECURE_HASH_LENGTH];
        Crypto::Hash(responseBuffer, SESSION_KEY_LENGTH + RANDOM_SEED_BYTE_LENGTH, challengeResponse, _currentHashVersion);

        this->_serverChallenge = new unsigned char[RANDOM_SEED_BYTE_LENGTH];
        CSPRNG::FillRandom(_serverChallenge, RANDOM_SEED_BYTE_LENGTH);

        //this->_serverRandomSalt,challengeResponse,serverChallenge
        authReply[0] = _currentHashVersion;
        authReply[1] = _currentCipherVersion;
        memcpy(authReply + 2, _serverRandomSalt, RANDOM_SEED_BYTE_LENGTH);
        memcpy(authReply + 2 + RANDOM_SEED_BYTE_LENGTH, challengeResponse, SECURE_HASH_LENGTH);
        memcpy(authReply + 2 + RANDOM_SEED_BYTE_LENGTH + SECURE_HASH_LENGTH, _serverChallenge, RANDOM_SEED_BYTE_LENGTH);

        return authReply;
    }
    else
    {
        throw BADSTATE_GET_AUTH_REPLY;
    }
}

void SimpPSKServer::AcceptAuthFinalize(unsigned char authFinalize[], unsigned int finalizeLength) //server
{
    //<client (challenge) response>
    if(finalizeLength != SECURE_HASH_LENGTH)
        throw INVALID_DATA;
    if(this->_state == STATE_SERVER_SENT_AUTH_REPLY)
    {
        this->_state = STATE_SERVER_RECEIVED_AUTH_FINALIZE;

        memcpy(_clientResponse, authFinalize, SECURE_HASH_LENGTH);
    }
    else
    {
       throw BADSTATE_ACCEPT_AUTH_FINALIZE;
    }
}
