/*
 *  crypto.cpp - supplies all of the hard crypto and hash selection to the SimpPSK library
 *  Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
 *
 *  Created and maintained by: FireXware  (OSSBox.com)
 *  Contact: firexware@gmail.com (If you need help, I certainly will if I have the time)
 *
 *  Copyright (C) 2010  FireXware
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/


#ifndef CRYPTO_H
#define CRYPTO_H


#include "constants.h"

extern "C" {
#include "sha256.h"
}

extern "C"{
#include "nessie.h" //WHIRLPOOL Hash function
}

namespace SHA512{ //name collusion with u64 in here and u64 from whirlpool
    extern "C"{
    #include "sha512.h"
    }
}

class Crypto
{
public:

    /*
     * Computes a hash.
     * data - the data to be hashed
     * dataLength - the length in bits of data
     * buf - a buffer to be filled with the hash (use GetHashLength to figure out the size)
     * hashVersion - the version code for the hash (HVER_* constant)
     */
    static void Hash(unsigned char data[], unsigned int dataLength, unsigned char buf[], unsigned char hashVersion)
    {
        switch(hashVersion)
        {
        case HVER_SHA256:
            sha256_context ctx;
            sha256_starts( &ctx );
            sha256_update( &ctx, data, dataLength );
            sha256_finish( &ctx, buf);
            break;
        case HVER_WHIRLPOOL:
            NESSIEstruct wp_ctx;
            NESSIEinit(&wp_ctx);
            NESSIEadd(data, 8 * dataLength, &wp_ctx); //bit-len not bytes
            NESSIEfinalize(&wp_ctx, buf);
            break;
        case HVER_SHA512:
            SHA512::sha512_ctx sha512ctx;
            SHA512::sha512_init_ctx(&sha512ctx);
            SHA512::sha512_process_bytes(data, dataLength, &sha512ctx);
            SHA512::sha512_finish_ctx(&sha512ctx,buf);
            break;
        default:
            throw UNSUPPORTED_VERSION;
        }
    }

    /*
     * Erases RAM contents by overwriting with 0x00
     * memory - pointer to the starting location in memory
     * len - the length of the memory in bytes
     */
    static void WipeMemory(unsigned char* memory, unsigned int len)
    {
        for(unsigned int i = 0; i < len; i++)
        {
            memory[i] = 0x00;
        }
    }

    /*
     * Returns the length of a hash in bytes
     * hashVersion - the HVER_* constant
     */
    static unsigned int GetHashLength(unsigned char hashVersion)
    {
        switch(hashVersion)
        {
        case HVER_SHA256:
            return SHA256_LENGTH;
            break;
        case HVER_WHIRLPOOL:
            return WHIRLPOOL_LENGTH;
            break;
        case HVER_SHA512:
            return SHA512_LENGTH;
        default:
            throw UNSUPPORTED_VERSION;
        }
    }

    /*
     * Gets a list of all safe hashes
     * returns - an array contaning the list of the HVER_* constants
     * len - gets filled with the length of the returned array
     * allowSHA256 - true to consider SHA256 secure
     * allowWHIRLPOOL - true to consider WHIRLPOOL secure
     */
    static unsigned char* GetHashVersions(unsigned int& len, bool allowSHA256, bool allowWHIRLPOOL, bool allowSHA512)
    {
        len = (int)allowSHA256 + (int)allowWHIRLPOOL + (int)allowSHA512;
        if(len == 0)
            throw NO_HASH_AGREEMENT;
        unsigned char* versions = new unsigned char[len];
        int idx = 0;
        if(allowSHA256)
            versions[idx++] = HVER_SHA256;
        if(allowWHIRLPOOL)
            versions[idx++] = HVER_WHIRLPOOL;
        if(allowSHA512)
            versions[idx++] = HVER_SHA512;
        return versions;
    }

    static unsigned char* GetCipherVersions(unsigned int& len, bool allowAES256, bool allowSERPENT256, bool allowTWOFISH256)
    {
        len = (int)allowAES256 + (int)allowSERPENT256 + (int)allowTWOFISH256;
        if(len == 0)
            throw NO_CIPER_AGREEMENT;
        unsigned char* versions = new unsigned char[len];
        int idx = 0;
        if(allowAES256)
            versions[idx++] = CVER_AES_256;
        if(allowSERPENT256)
            versions[idx++] = CVER_SERPENT_256;
        if(allowTWOFISH256)
            versions[idx++] = CVER_TWOFISH_256;
        return versions;
    }

};


#endif // CRYPTO_H
