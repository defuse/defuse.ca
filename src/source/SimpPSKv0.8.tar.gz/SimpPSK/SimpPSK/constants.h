/*
 *  constants.h - constants used in SimpPSK for error codes, hash types, states, etc..
 *  Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
 *
 *  Created and maintained by: FireXware  (OSSBox.com)
 *  Contact: firexware@gmail.com (If you need help, I certainly will if I have the time)
 *
 *  Copyright (C) 2010  FireXware
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/


//constants
#define RANDOM_SEED_BYTE_LENGTH 32 //size of the random data used in key exchange
#define SESSION_KEY_LENGTH 32

//states
#define STATE_NONE 0
#define STATE_CLIENT_SENT_AUTH 1
#define STATE_SERVER_GOT_AUTH 2
#define STATE_SERVER_SENT_AUTH_REPLY 3
#define STATE_CLIENT_GOT_AUTH_REPLY 4
#define STATE_CLIENT_SENT_AUTH_FINALIZE 5
#define STATE_SERVER_RECEIVED_AUTH_FINALIZE 6
#define STATE_AUTHENTICATED 7

//errors
#define RNG_FAIL 0
#define BADSTATE_START_AUTH_REQUEST 1
#define BADSTATE_ACCEPT_AUTH_REQUEST 2
#define BADSTATE_GET_AUTH_REPLY 3
#define BADSTATE_ACCEPT_AUTH_REPLY 4
#define BADSTATE_GET_AUTH_FINALIZE 5
#define BADSTATE_ACCEPT_AUTH_FINALIZE 6
#define BADSTATE_VALID_AUTHENTICATION 7
#define BADSTATE_GET_SESSION_KEY 8
#define BADSTATE_GET_AGREED_HASH 9
#define UNSUPPORTED_VERSION 10
#define INVALID_DATA 11
#define NO_HASH_AGREEMENT 12
#define NO_CIPER_AGREEMENT 13

//hash versions
#define HVER_SHA256 20
#define HVER_SHA512 23
#define HVER_WHIRLPOOL 25


//hash info
#define SHA256_LENGTH 32
#define WHIRLPOOL_LENGTH 64
#define SHA512_LENGTH 64

//cipher versions
#define CVER_AES_256    10
#define CVER_SERPENT_256    20
#define CVER_TWOFISH_256    30

//cipher info
#define AES_256_BLOCKSIZE 16
#define AES_256_KEYSIZE 32

#define SERPENT_256_BLOCKSIZE 16
#define SERPENT_256_KEYSIZE 32

#define TWOFISH_256_BLOCKSIZE 16
#define TWOFISH_256_KEYSIZE 32
