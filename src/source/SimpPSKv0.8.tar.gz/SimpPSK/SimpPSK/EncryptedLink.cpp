//EncryptedLink.h
//Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
//Created by FireXware
//Contact: firexware@gmail.com
//Website: OSSBox.com

#include "EncryptedLink.h"

EncryptedLink::EncryptedLink()
{
    //ctor
}

EncryptedLink::~EncryptedLink()
{
    //dtor
}
