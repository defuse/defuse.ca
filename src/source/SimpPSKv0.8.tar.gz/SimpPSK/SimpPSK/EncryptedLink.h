//EncryptedLink.h
//Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
//Created by FireXware
//Contact: firexware@gmail.com
//Website: OSSBox.com

#ifndef ENCRYPTEDLINK_H
#define ENCRYPTEDLINK_H

//IMPORTANT: we can probably do the 2 differnt key approach, one constructor that takes SimpPSKServer and one that takes client, to get order correct
/*
Crypto:

1. The encryption key is created by H(sessionKey . NUMS_1)
2. The HMAC key is created by H(sessionKey . NUMS_2)
3. The IV key is created by H(sessionKey . NUMS_3)

First packet encryption
block_size counter init to 0
random block_size data generated (used for IV)
IV = H(IV . counter . IV_KEY)
using that IV, data is encrypted in CBC mode using that IV and the encryption key
data = IV.data
checksum = HMAC(data, HMAC_KEY)
data = checksum.data (checksum.iv.data)
**save the IV so replay attack can be avoided by checking recieving message doesnt have that IV* <-- when asking for peer review make it a challenge to find this problem

Decryption is reverse

next message:
counter incremented,
grabbed last ciphertext block
new iv computed (same as above, with last ciphertext block instead of 'IV' in the hash)
IV NOT SENT with the message

*/

/*notes
IV = H(IV_key . decryption_counter . last_ciphertext_block (or random IV that gets sent first time))
//TODO: when making the encryption, make it a friend so u can give the SimpPSK instance as constructor arg, uses the previously-decided upon hash

//do the two-way stream thing, except MAKE SURE the first IV isn't the same so the first packet sent can't be replayed as the first packet recieved
*/

/*
EncryptedLink provides allows two parties who share a key, to communicate
through an encrypted channel. Using EncryptedLink ensures data confidentiality
and prevents replay attacks.


*/
class EncryptedLink
{
    public:
        EncryptedLink(unsigned char* sessionKey, unsigned int keyLength, unsigned char hashVersion, unsigned char cipherVersion);
        virtual ~EncryptedLink();

        //CANT DO ROLLING CBC! - read wiki

        /*
        what if:
        -don't want to send an IV
        -don't want to send
        */
        //Rolling CBC where IV=H(last ciphertext . key) for every new message
        //overhead:
        //one time IV
        //32 bytes of HMAC
        //possible 16 bytes of padding
        //48 bytes of overhead
        unsigned char* EncryptMessage(unsigned char plaintext[], unsigned int ptLen, unsigned int &ctLen);
        unsigned char* DecryptMessage(unsigned char ciphertext[], unsigned int ctLen, unsigned int &messageLen);

    protected:
    private:
        EncryptedLink();

        unsigned char* _hmacKey;
        unsigned char* _ivKey;
        unsigned char* _cipherKey;
        unsigned char* _messageCount; //next message IV = HMAC(_ivKey, _messageCount . _lastIv)

};

#endif // ENCRYPTEDLINK_H
