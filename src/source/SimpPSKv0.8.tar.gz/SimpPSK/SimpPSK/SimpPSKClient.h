/*
 *  SimpPSKClient.h - the client part of SimpPSK
 *  Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
 *
 *  Created and maintained by: FireXware  (OSSBox.com)
 *  Contact: firexware@gmail.com (If you need help, I certainly will if I have the time)
 *
 *  Copyright (C) 2010  FireXware
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef SIMPPSKCLIENT_H
#define SIMPPSKCLIENT_H


#include "SimpPSK.h"
/*
 * SimpPSKClient inherids SimpPSK
 * This class is used for the party that sends the first part of the 3-way handshake.
 * It then accepts the reply from the server, and sends the final part to complete the handshake
 *
 * USAGE:
 *
 */
class SimpPSKClient: public SimpPSK
{
    public:
        /*
         * key - the secret key that is shared between both parties, it is safe for this to be an ASCII password
         * keyLength - the length of 'key' in bytes
         * allowSHA256 - set true if SHA256 should be allowed to be used
         */
        SimpPSKClient(unsigned char key[], unsigned int keyLength);

        /*
         * Obtains the first part of the three way handshake
         * returns a pointer to the first packet to send - byte array - (on the heap ofc.)
         * len is filled with the length of the returned array
         * Possible errors:
         * BADSTATE_START_AUTH_REQUEST - if this is called at the wrong time, i.e after the handshake is complete
         */
        unsigned char* StartAuthRequest(int &len);

        /*
         * Accepts the server's reply (2nd part of the 3-way handshake) to the packet given by StartAuthRequest
         * authReply is the packet sent by the server
         * replyLength is the length of that packet
         * Possible errors:
         * BADSTATE_START_AUTH_REQUEST - if this is called at the wrong time, i.e after the handshake is complete
         * INVALID_DATA - if the data provided isn't the same as what was sent by the server (most commonly the wrong size)
         * NO_HASH_AGREEMENT - if the server chose to use a dissallowed hash. This would only ever happen if the packet
         * coming back from the server was modified. This should be taken as a sign of attack and the connection should be dropped.
         */
        void AcceptAuthReply(unsigned char authReply[], unsigned int replyLength);

        /*
         * Returns the final step of the 3-way handshake, to be sent to the server.
         * len is filled with the length of the returned array.
         * Possible errors:
         * BADSTATE_START_AUTH_REQUEST - if this is called at the wrong time, i.e after the handshake is complete
         */
        unsigned char* GetAuthFinalize(int &len);

    protected:

    private:

};

#endif // SIMPPSKCLIENT_H
