/*
 *  SimpPSKServer.h - the server part of SimpPSK
 *  Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
 *
 *  Created and maintained by: FireXware  (OSSBox.com)
 *  Contact: firexware@gmail.com (If you need help, I certainly will if I have the time)
 *
 *  Copyright (C) 2010  FireXware
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef SIMPPSKSERVER_H
#define SIMPPSKSERVER_H

#include "constants.h"
#include "SimpPSK.h"

/*
 * SimpPSKServer inherits SimpPSK
 * This class is used for the party that is listening for connections, and recieves the first part of the 3 way handshake
 * it then provides the second step of the three way handshake, and receives the third.
 */
class SimpPSKServer: public SimpPSK
{
    public:
        /*
         * key - the secret key that is shared between both parties, it is safe for this to be an ASCII password
         * keyLength - the length of key, in bytes
         * preferredHash - the hash to be chosen if the client supports it (this will override the following bool variables)
         * allowSHA256 - allow the use of the SHA256 hash
         */
        SimpPSKServer(unsigned char key[], unsigned int keyLength, unsigned char preferredHash = HVER_SHA256, unsigned char preferredCipher = CVER_AES_256);

        /*
         * Accepts the first part of the 3-way handshake from the client
         * authRequest - the first part of the 3-way handshake from the client
         * requestLength - the length of the authRequest in bytes
         * Possible Errors:
         * BADSTATE_START_AUTH_REQUEST - if this is called at the wrong time, i.e after the handshake is complete
         * INVALID_DATA - if the data provided isn't the same as what was sent by the client (most commonly the wrong size)
         * NO_HASH_AGREEMENT - if no hash alg. can be agreed upon based on the client's and server's prefrences
         * also a possible sign of malicious attack, the connection should be dropped.
         */
        void AcceptAuthRequest(unsigned char authRequest[], unsigned int requestLength);

        /*
         * Gets the 2nd part of the 3-way handshake to send to the client
         * Returns a pointer to the 2nd part on the heap
         * fills len with the length of the array
         * Possible Errors:
         * BADSTATE_START_AUTH_REQUEST - if this is called at the wrong time, i.e after the handshake is complete
         */
        unsigned char* GetAuthReply(int &len);
        void AcceptAuthFinalize(unsigned char authFinalize[], unsigned int finalizeLength);

    protected:
        unsigned char _preferredHash;
        unsigned char _preferredCipher;
    private:
};

#endif // SIMPPSKSERVER_H
