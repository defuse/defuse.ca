/*
 *  SimpPSKClient.cpp - the client part of SimpPSK
 *  Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
 *
 *  Created and maintained by: FireXware  (OSSBox.com)
 *  Contact: firexware@gmail.com (If you need help, I certainly will if I have the time)
 *
 *  Copyright (C) 2010  FireXware
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "SimpPSKClient.h"

#include "csprng.cpp"
#include "crypto.cpp"
#include <string.h>

SimpPSKClient::SimpPSKClient(unsigned char key[], unsigned int keyLength)
: SimpPSK(key,keyLength)
{
    _allocatedHashDependantData = false;
}

unsigned char* SimpPSKClient::StartAuthRequest(int &len)
{
    //<client salt> . <client challenge>
    if(_state == STATE_NONE)
    {
        unsigned int numHashVers = 0;
        unsigned char* hashVersions = Crypto::GetHashVersions(numHashVers, _allowSHA256, _allowWHIRLPOOL, _allowSHA512);

        unsigned int numCipherVers = 0;
        unsigned char* cipherVersions = Crypto::GetCipherVersions(numCipherVers, _allowAES256, _allowSERPENT256, _allowTWOFISH256);

        len = 2 * RANDOM_SEED_BYTE_LENGTH + 1 + numHashVers + 1 + numCipherVers;
        unsigned char* authRequest = new unsigned char[len];
        _state = STATE_CLIENT_SENT_AUTH;

        CSPRNG::FillRandom(_clientChallenge, RANDOM_SEED_BYTE_LENGTH);
        CSPRNG::FillRandom(_clientRandomSalt, RANDOM_SEED_BYTE_LENGTH);

        memcpy(authRequest, _clientRandomSalt, RANDOM_SEED_BYTE_LENGTH);
        memcpy(authRequest + RANDOM_SEED_BYTE_LENGTH, _clientChallenge, RANDOM_SEED_BYTE_LENGTH);
        authRequest[2 * RANDOM_SEED_BYTE_LENGTH] = (unsigned char)(numHashVers % 256);
        memcpy(authRequest + 2 * RANDOM_SEED_BYTE_LENGTH + 1, hashVersions, numHashVers);
        authRequest[2 * RANDOM_SEED_BYTE_LENGTH + 1 + numHashVers] = numCipherVers % 256;
        memcpy(authRequest + 2 * RANDOM_SEED_BYTE_LENGTH + 1 + numHashVers + 1, cipherVersions, numCipherVers);
        delete[] hashVersions;
        delete[] cipherVersions;
        return authRequest;
    }
    else
    {
        throw BADSTATE_START_AUTH_REQUEST;
    }
}

void SimpPSKClient::AcceptAuthReply(unsigned char authReply[], unsigned int replyLength) //client
{
    //<hash version> . <server salt> . <server (challenge) response> . <server challenge>
    if(this->_state == STATE_CLIENT_SENT_AUTH)
    {
        this->_state = STATE_CLIENT_GOT_AUTH_REPLY;

        if(replyLength < 2)
            throw INVALID_DATA;
        _currentHashVersion = authReply[0];
        _currentCipherVersion = authReply[1];

        //double check for security incase an attacker changed the server's reply
        if(!IsOkHashVersion(_currentHashVersion, _allowSHA256, _allowWHIRLPOOL, _allowSHA512))
            throw NO_HASH_AGREEMENT;

        if(!IsOKCipherVersion(_currentCipherVersion, _allowAES256, _allowSERPENT256, _allowTWOFISH256))
            throw NO_CIPER_AGREEMENT;

        SECURE_HASH_LENGTH = Crypto::GetHashLength(_currentHashVersion);

        _clientResponse = new unsigned char[SECURE_HASH_LENGTH];
        _serverResponse = new unsigned char[SECURE_HASH_LENGTH];
        _allocatedHashDependantData = true;

        if(replyLength < 2 + 2 * RANDOM_SEED_BYTE_LENGTH + SECURE_HASH_LENGTH)
            throw INVALID_DATA;
        memcpy(_serverRandomSalt, authReply + 2, RANDOM_SEED_BYTE_LENGTH);
        memcpy(_serverResponse, authReply + 2 + RANDOM_SEED_BYTE_LENGTH, SECURE_HASH_LENGTH);
        memcpy(_serverChallenge, authReply + 2 + RANDOM_SEED_BYTE_LENGTH + SECURE_HASH_LENGTH, RANDOM_SEED_BYTE_LENGTH);

        CreateSessionKey();
    }
    else
    {
        throw BADSTATE_ACCEPT_AUTH_REPLY;
    }
}

unsigned char* SimpPSKClient::GetAuthFinalize(int& len) //client
{
    //<client (challenge) response>
    if(this->_state == STATE_CLIENT_GOT_AUTH_REPLY)
    {
        this->_state = STATE_CLIENT_SENT_AUTH_FINALIZE;

        len = SECURE_HASH_LENGTH;
        unsigned char* authFinalize = new unsigned char[len];
        //reply with challenge response
        unsigned char responseBuffer[SESSION_KEY_LENGTH + RANDOM_SEED_BYTE_LENGTH]; //sessionkey . challenge
        memcpy(responseBuffer, this->_sessionKey, SESSION_KEY_LENGTH);
        memcpy(responseBuffer + SESSION_KEY_LENGTH, this->_serverChallenge, RANDOM_SEED_BYTE_LENGTH);

        Crypto::Hash(responseBuffer, SESSION_KEY_LENGTH + RANDOM_SEED_BYTE_LENGTH, authFinalize, _currentHashVersion);
        return authFinalize;
    }
    else
    {
        throw BADSTATE_GET_AUTH_FINALIZE;
    }
}

