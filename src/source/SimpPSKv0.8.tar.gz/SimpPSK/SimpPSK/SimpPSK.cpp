/*
 *  SimpPSK.cpp - allows two endpoints to agree upon a random session key, using a pre-shared for authentication.
 *  Part of the SimpPSK library: http://ossbox.com/index.php?page=simppsk
 *
 *  Created and maintained by: FireXware  (OSSBox.com)
 *  Contact: firexware@gmail.com (If you need help, I certainly will if I have the time)
 *
 *  Copyright (C) 2010  FireXware
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include "SimpPSK.h"
#include "csprng.cpp"
#include "crypto.cpp"
#include <string.h>

SimpPSK::SimpPSK(unsigned char key[], unsigned int keyLength)
{
    //hash security defaults
    _allowSHA256 = true;
    _allowWHIRLPOOL = true;
    _allowSHA512 = true;

    //cipher security defaults
    _allowAES256 = true;
    _allowSERPENT256 = true;
    _allowTWOFISH256 = true;

    _state = STATE_NONE;
    SHARED_KEY_LENGTH = keyLength;

    //here we allocate everything that we know the size of
    //the client and server have to allocate them at different times
    _sharedKey = new unsigned char[SHARED_KEY_LENGTH];
    _serverRandomSalt = new unsigned char[RANDOM_SEED_BYTE_LENGTH];
    _clientRandomSalt = new unsigned char[RANDOM_SEED_BYTE_LENGTH];
    _clientChallenge = new unsigned char[RANDOM_SEED_BYTE_LENGTH];
    _serverChallenge = new unsigned char[RANDOM_SEED_BYTE_LENGTH];
    _sessionKey = new unsigned char[SESSION_KEY_LENGTH];

    memcpy(_sharedKey, key, SHARED_KEY_LENGTH);
}

SimpPSK::~SimpPSK()
{
    DestroyKeyData();
    if(_allocatedHashDependantData)
    {
        delete[] _serverResponse;
        delete[] _clientResponse;
    }
    delete[] _sessionKey;
    delete[] _sharedKey;
    delete[] _serverRandomSalt;
    delete[] _clientRandomSalt;
    delete[] _clientChallenge;
    delete[] _serverChallenge;
}

int SimpPSK::GetState()
{
    return _state;
}

void SimpPSK::SetAllowedHashTypes(bool allowSHA256, bool allowWHIRLPOOL, bool allowSHA512)
{
    _allowSHA256 = allowSHA256;
    _allowWHIRLPOOL = allowWHIRLPOOL;
    _allowSHA512 = allowSHA512;
}

void SimpPSK::SetAllowedCipherTypes(bool allowAES256, bool allowSERPENT256, bool allowTWOFISH256)
{
    _allowAES256 = allowAES256;
    _allowSERPENT256 = allowSERPENT256;
    _allowTWOFISH256 = allowTWOFISH256;
}

void SimpPSK::DestroyKeyData()
{
    if(_allocatedHashDependantData)
    {
        Crypto::WipeMemory(_clientResponse, SECURE_HASH_LENGTH);
        Crypto::WipeMemory(_serverResponse, SECURE_HASH_LENGTH);

    }
    Crypto::WipeMemory(_sessionKey, SESSION_KEY_LENGTH);
    Crypto::WipeMemory(_sharedKey, SHARED_KEY_LENGTH);
    Crypto::WipeMemory(_serverRandomSalt, RANDOM_SEED_BYTE_LENGTH);
    Crypto::WipeMemory(_clientRandomSalt, RANDOM_SEED_BYTE_LENGTH);
    Crypto::WipeMemory(_clientChallenge, RANDOM_SEED_BYTE_LENGTH);
    Crypto::WipeMemory(_serverChallenge, RANDOM_SEED_BYTE_LENGTH);
}

bool SimpPSK::ValidAuthentication()
{
    if(_state == STATE_CLIENT_SENT_AUTH_FINALIZE)
    {
        unsigned char hash[SECURE_HASH_LENGTH];
        ComputeChallengeResponse(_clientChallenge, hash);
        if(memcmp(hash, _serverResponse, SECURE_HASH_LENGTH) == 0)
        {
            _state = STATE_AUTHENTICATED;
            return true;
        }
        else
        {
            return false;
        }
    }
    else if(_state == STATE_SERVER_RECEIVED_AUTH_FINALIZE)
    {
        unsigned char hash[SECURE_HASH_LENGTH];
        ComputeChallengeResponse(_serverChallenge, hash);
        if(memcmp(hash, _clientResponse, SECURE_HASH_LENGTH) == 0)
        {
            _state = STATE_AUTHENTICATED;
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        throw BADSTATE_VALID_AUTHENTICATION;
    }
}

unsigned char* SimpPSK::GetSessionKey(int& len)
{
    if(_state == STATE_AUTHENTICATED)
    {
        len = SESSION_KEY_LENGTH;
        unsigned char* keyBuf = new unsigned char[SESSION_KEY_LENGTH];
        memcpy(keyBuf, _sessionKey, SESSION_KEY_LENGTH);
        return keyBuf;
    }
    else
    {
        throw BADSTATE_GET_SESSION_KEY;
    }
}

unsigned char SimpPSK::GetAgreedHash()
{
    if(_state == STATE_AUTHENTICATED)
    {
        return _currentHashVersion;
    }
    else
    {
        return BADSTATE_GET_AGREED_HASH;
    }
}

unsigned char SimpPSK::GetAgreedCipher()
{
    if(_state == STATE_AUTHENTICATED)
    {
        return _currentCipherVersion;
    }
    else
    {
        return BADSTATE_GET_AGREED_HASH;
    }
}

std::string SimpPSK::GetErrorMessage(int errnum)
{
    switch(errnum)
    {
    case RNG_FAIL:
        return "RNG_FAIL";
    case BADSTATE_START_AUTH_REQUEST:
        return "BADSTATE_START_AUTH_REQUEST";
    case BADSTATE_ACCEPT_AUTH_REQUEST:
        return "BADSTATE_ACCEPT_AUTH_REQUEST";
    case BADSTATE_GET_AUTH_REPLY:
        return "BADSTATE_GET_AUTH_REPLY";
    case BADSTATE_ACCEPT_AUTH_REPLY:
        return "BADSTATE_ACCEPT_AUTH_REPLY";
    case BADSTATE_GET_AUTH_FINALIZE:
        return "BADSTATE_GET_AUTH_FINALIZE";
    case BADSTATE_ACCEPT_AUTH_FINALIZE:
        return "BADSTATE_ACCEPT_AUTH_FINALIZE";
    case BADSTATE_VALID_AUTHENTICATION:
        return "BADSTATE_VALID_AUTHENTICATION";
    case BADSTATE_GET_SESSION_KEY:
        return "BADSTATE_GET_SESSION_KEY";
    case UNSUPPORTED_VERSION:
        return "UNSUPPORTED_VERSION";
    case INVALID_DATA:
        return "INVALID_DATA";
    case NO_HASH_AGREEMENT:
        return "NO_HASH_AGREEMENT";
    case NO_CIPER_AGREEMENT:
        return "NO_CIPER_AGREEMENT";
    default:
        return "UNKNOWN";
    }
}
//private
void SimpPSK::CreateSessionKey()
{
    if(SECURE_HASH_LENGTH < SESSION_KEY_LENGTH)
        throw "Hashes with an output size less than 256 bits can't be a part of this library!";

    unsigned char allData[SHARED_KEY_LENGTH + 2 * RANDOM_SEED_BYTE_LENGTH];

    memcpy(allData, _sharedKey, SHARED_KEY_LENGTH);
    memcpy(allData + SHARED_KEY_LENGTH, _clientRandomSalt, RANDOM_SEED_BYTE_LENGTH);
    memcpy(allData + SHARED_KEY_LENGTH + RANDOM_SEED_BYTE_LENGTH, _serverRandomSalt, RANDOM_SEED_BYTE_LENGTH);

    unsigned char hash[SECURE_HASH_LENGTH];
    Crypto::Hash(allData, SHARED_KEY_LENGTH + 2 * RANDOM_SEED_BYTE_LENGTH, hash, _currentHashVersion);
    memcpy(_sessionKey, hash, SESSION_KEY_LENGTH);
}

void SimpPSK::ComputeChallengeResponse(unsigned char challenge[], unsigned char responseBuf[])
{
    unsigned char responseBuffer[SESSION_KEY_LENGTH + RANDOM_SEED_BYTE_LENGTH]; //sessionkey . challenge

    memcpy(responseBuffer, this->_sessionKey, SESSION_KEY_LENGTH);
    memcpy(responseBuffer + SESSION_KEY_LENGTH, challenge, RANDOM_SEED_BYTE_LENGTH);

    Crypto::Hash(responseBuffer, SESSION_KEY_LENGTH + RANDOM_SEED_BYTE_LENGTH, responseBuf, _currentHashVersion);
}

unsigned char SimpPSK::GetBestHashVersion(unsigned char* allowedHashes, unsigned int numHashes, unsigned char preferredHash, bool allowSHA256, bool allowWHIRLPOOL, bool allowSHA512)
{
    //first see if the preferred one is allowed
    for(unsigned int i = 0; i < numHashes; i++)
    {
        if(allowedHashes[i] == preferredHash && IsOkHashVersion(preferredHash, allowSHA256, allowWHIRLPOOL, allowSHA512))
            return preferredHash;
    }

    //if not, choose one we both agree on
    for(unsigned int i = 0; i < numHashes; i++)
    {
        switch(allowedHashes[i])
        {
        case HVER_SHA256:
            if(allowSHA256)
                return HVER_SHA256;
        case HVER_WHIRLPOOL:
            if(allowWHIRLPOOL)
                return HVER_WHIRLPOOL;
        case HVER_SHA512:
            if(allowSHA512)
                return HVER_SHA512;
        }
    }

    //we don't agree on any
    throw NO_HASH_AGREEMENT;
}

unsigned char SimpPSK::GetBestCipherVersion(unsigned char* allowedCiphers, unsigned int numCiphers, unsigned char preferredCipher, bool allowAES256, bool allowSERPENT256, bool allowTWOFISH256)
{
    for(unsigned char i = 0; i < numCiphers; i++)
    {
        if(allowedCiphers[i] == preferredCipher && IsOKCipherVersion(allowedCiphers[i], allowAES256, allowSERPENT256, allowTWOFISH256))
            return preferredCipher;
    }

    for(unsigned int i = 0; i < numCiphers; i++)
    {
        switch(allowedCiphers[i])
        {
        case CVER_AES_256:
            return allowAES256;
        case CVER_SERPENT_256:
            return allowSERPENT256;
        case CVER_TWOFISH_256:
            return allowTWOFISH256;
        }
    }

    throw NO_CIPER_AGREEMENT;
}

bool SimpPSK::IsOkHashVersion(unsigned char hashVersion, bool allowSHA256, bool allowWHIRLPOOL, bool allowSHA512)
{
    switch(hashVersion)
    {
    case HVER_SHA256:
        return allowSHA256;
    case HVER_WHIRLPOOL:
        return allowWHIRLPOOL;
    case HVER_SHA512:
        return allowSHA512;
    default:
        return false;
    }
}

bool SimpPSK::IsOKCipherVersion(unsigned char cipherVersion, bool allowAES256, bool allowSERPENT256, bool allowTWOFISH256)
{
    switch(cipherVersion)
    {
    case CVER_AES_256:
        return allowAES256;
    case CVER_SERPENT_256:
        return allowSERPENT256;
    case CVER_TWOFISH_256:
        return allowTWOFISH256;
    default:
        return false;
    }
}
