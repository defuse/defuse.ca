<html>
	<head>
		<title>PDF Exploit Sanitizer</title>
	</head>
<body>
<div style="width:800px; margin: 0 auto;">
	<center>
		<h1 style="margin:0; padding:0;">PDFCleaner</h1>
		PDF Exploit Sanitizer by <a href="http://ossbox.com/">OSSBox</a>
	</center>
	<br />
	<div style="text-align:left; margin:">
		<form action="sani.php" method="post" enctype="multipart/form-data">
			<table style="margin: 0 auto">
				<tr><td>PDF File:</td><td><input type="file" name="pdffile" checked="true" /></td></tr>
				<tr><td>Download:</td><td><input type="radio" name="want" value="pdf" />PDF 
					<input type="radio" name="want" value="ps" />PostScript 
					<input type="radio" name="want" value="text" />Plain Text</td></tr>
				<tr><td></td><td><input type="submit" name="clean" value="Sanitize" style="width:300px"/></td></tr>
			</table>
		</form>
		<br />
		<center>PDFs Cleaned: <?php
		$dbhost = 'localhost';
		$dbuser = '';
		$dbpass = '';

		$conn = mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
		$dbname = '';
		mysql_select_db($dbname);

		$q = mysql_query("SELECT * FROM ctr");
		$q = mysql_fetch_array($q);
		echo $q['count'];
		?></center>
	<h2>What is PDFCleaner?</h2>
	Lately, there have been many new exploits against Adobe Acrobat Reader. Before now, the only way to protect yourself was to use a different program to open PDF files, so I created PDFCleaner. 
	<br /><br />
	PDFCleaner is a service that lets you upload a potentially dangerous PDF file and download a safe, clean, sanitized version of the same file.
	<h2>How Does it Work?</h2>
	Simple. PDFCleaner converts your PDF file to PostScript format, and then converts it back into a PDF file. The process of interpreting the PDF file, converting it to a different format, and converting that back into PDF ensures that any PDF-specific exploits are not transfered to the new pdf file. 
	The PostScript is a file format can do almost everything that PDF can do, so in most cases, the resulting PDF file will look exactly the same.  
	<h2>Is My Data Safe?</h2>
	Yes, every file you upload is deleted when you download the new file.
	<h2>Why Online?</h2>
	If we were to make a program to do this on your computer, your computer still has to process the dangerous PDF file, and could be exploited. So it is safer to have our server do it for you.
	</div>
</div>

</body>
</html>
